import { Link } from "wouter";
import {
  Calendar,
  CalendarDays,
  DollarSign,
  Percent,
  ArrowUpDown,
  Zap,
  Clock,
  Moon,
  Calculator,
  FileText
} from "lucide-react";

interface CalculatorCardProps {
  id: string;
  name: string;
  description: string;
  path: string;
  iconName: string;
}

// Map icon names to components
const iconMap: Record<string, React.ElementType> = {
  "calendar": Calendar,
  "calendar-days": CalendarDays,
  "dollar-sign": DollarSign,
  "percent": Percent,
  "arrows-up-down": ArrowUpDown,
  "zap": Zap,
  "clock": Clock,
  "moon": Moon,
  "calculator": Calculator,
  "file-text": FileText
};

const CalculatorCard: React.FC<CalculatorCardProps> = ({ id, name, description, path, iconName }) => {
  // Get the icon component based on the name
  const IconComponent = iconMap[iconName] || Calendar;
  
  return (
    <div className="calculator-card bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-all">
      <div className="p-6">
        <div className="w-12 h-12 rounded-full bg-primary-100 flex items-center justify-center mb-4">
          <div className="h-6 w-6 text-primary-500">
            <IconComponent size={24} />
          </div>
        </div>
        <h3 className="text-xl font-semibold text-gray-900 mb-2">{name}</h3>
        <p className="text-gray-600 mb-4">{description}</p>
        <Link 
          href={path}
          className="inline-flex items-center text-primary-600 hover:text-primary-700"
        >
          Try it now
          <svg className="ml-1 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"></path>
          </svg>
        </Link>
      </div>
    </div>
  );
};

export default CalculatorCard;
