import { Link, useLocation } from "wouter";
import { calculators } from "@/utils/calculatorData";

interface SidebarProps {
  isOpen: boolean;
  closeSidebar: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, closeSidebar }) => {
  const [location] = useLocation();
  
  return (
    <div 
      className={`fixed inset-y-0 left-0 z-50 transform ${isOpen ? 'translate-x-0' : '-translate-x-full'} md:relative md:translate-x-0 transition duration-200 ease-in-out md:flex md:w-64 bg-white md:border-r border-gray-200 shadow-lg md:shadow-none`}
    >
      <div className="flex flex-col h-full">
        {/* Logo Section */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          <Link href="/" className="flex items-center">
            <svg className="h-8 w-8 text-primary-500" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"></path>
            </svg>
            <span className="ml-2 text-lg font-semibold">Daily Need Calculators</span>
          </Link>
          <button 
            onClick={closeSidebar}
            className="md:hidden p-2 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-100"
            aria-label="Close menu"
          >
            <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
            </svg>
          </button>
        </div>
        
        {/* Navigation Links */}
        <nav className="flex-1 py-4 overflow-y-auto custom-scrollbar">
          <div className="px-4 mb-4">
            <h2 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Calculators</h2>
          </div>
          
          <ul className="space-y-1">
            {calculators.map((calculator) => (
              <li key={calculator.id}>
                <Link 
                  href={calculator.path}
                  onClick={closeSidebar} 
                  className={`flex items-center px-4 py-3 text-sm font-medium rounded-md group ${
                    location === calculator.path 
                    ? 'bg-gray-100 text-primary-500' 
                    : 'text-gray-700 hover:bg-gray-100 hover:text-primary-500'
                  }`}
                >
                  <span className="h-5 w-5 mr-3 text-gray-500 group-hover:text-primary-500">
                    {calculator.icon}
                  </span>
                  {calculator.name}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </div>
  );
};

export default Sidebar;
