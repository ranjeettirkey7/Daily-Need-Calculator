import { calculators } from "@/utils/calculatorData";
import CalculatorCard from "@/components/CalculatorCard";

const Home = () => {
  return (
    <div id="welcome-screen" className="max-w-7xl mx-auto">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">Welcome to Daily Need Calculators</h1>
      <p className="text-lg text-gray-600 mb-8">A suite of useful real-time calculators for your everyday life tasks.</p>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {calculators.map((calculator) => (
          <CalculatorCard 
            key={calculator.id}
            id={calculator.id}
            name={calculator.name}
            description={calculator.description}
            path={calculator.path}
            icon={calculator.icon}
          />
        ))}
      </div>
    </div>
  );
};

export default Home;
