import { useState, useEffect } from "react";
import { calculateTax } from "@/utils/calculatorUtils";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Card, CardContent } from "@/components/ui/card";

const TaxCalculator = () => {
  const [amount, setAmount] = useState<string>("");
  const [taxRate, setTaxRate] = useState<string>("10");
  const [includeTax, setIncludeTax] = useState<boolean>(false);
  const [result, setResult] = useState<{
    taxAmount: number;
    totalAmount: number;
  } | null>(null);

  // Calculate tax
  const handleCalculateTax = () => {
    const amountValue = parseFloat(amount) || 0;
    const taxRateValue = parseFloat(taxRate) || 0;
    
    const result = calculateTax(amountValue, taxRateValue, includeTax);
    setResult(result);
  };

  // Recalculate when inputs change
  useEffect(() => {
    handleCalculateTax();
  }, [amount, taxRate, includeTax]);

  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">GST / Tax Calculator</h1>
      <p className="text-lg text-gray-600 mb-8">
        Calculate tax-inclusive or tax-exclusive prices with GST or other tax percentages.
      </p>
      
      <Card className="mb-8">
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <Label htmlFor="amount" className="block text-sm font-medium text-gray-700 mb-1">
                Amount
              </Label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <span className="text-gray-500 sm:text-sm">₹</span>
                </div>
                <Input
                  type="number"
                  id="amount"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  min="0"
                  step="0.01"
                  placeholder="0.00"
                  className="w-full pl-7"
                  required
                />
              </div>
            </div>
            <div>
              <Label htmlFor="taxRate" className="block text-sm font-medium text-gray-700 mb-1">
                Tax / GST Rate
              </Label>
              <div className="relative">
                <Input
                  type="number"
                  id="taxRate"
                  value={taxRate}
                  onChange={(e) => setTaxRate(e.target.value)}
                  min="0"
                  max="100"
                  step="0.1"
                  placeholder="10"
                  className="w-full pr-9"
                  required
                />
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                  <span className="text-gray-500 sm:text-sm">%</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mb-6">
            <Label className="block text-sm font-medium text-gray-700 mb-2">
              Calculation Method
            </Label>
            <RadioGroup
              value={includeTax ? "inclusive" : "exclusive"}
              onValueChange={(value) => setIncludeTax(value === "inclusive")}
              defaultValue="exclusive"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="exclusive" id="exclusive" />
                <Label htmlFor="exclusive" className="cursor-pointer">
                  Add Tax (The amount doesn't include tax)
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="inclusive" id="inclusive" />
                <Label htmlFor="inclusive" className="cursor-pointer">
                  Remove Tax (The amount already includes tax)
                </Label>
              </div>
            </RadioGroup>
          </div>
          
          <div className="grid grid-cols-2 gap-4 mb-6">
            {[5, 10, 15, 18, 20, 28].map((rate) => (
              <button
                key={rate}
                type="button"
                onClick={() => setTaxRate(rate.toString())}
                className={`py-1 px-3 border rounded-md text-sm ${
                  taxRate === rate.toString()
                    ? 'bg-primary-100 text-primary-700 border-primary-300'
                    : 'bg-gray-100 text-gray-700 border-gray-200 hover:bg-gray-200'
                }`}
              >
                {rate}%
              </button>
            ))}
          </div>
          
          {result && parseFloat(amount) > 0 && (
            <div className="mt-6 border-t border-gray-200 pt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <div className="text-sm text-gray-600 mb-1">Tax Amount</div>
                  <div className="text-3xl font-bold text-primary-600">
                    ₹{result.taxAmount.toFixed(2)}
                  </div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <div className="text-sm text-gray-600 mb-1">
                    {includeTax ? "Amount Without Tax" : "Total Amount (With Tax)"}
                  </div>
                  <div className="text-3xl font-bold text-primary-600">
                    ₹{includeTax ? (parseFloat(amount) - result.taxAmount).toFixed(2) : result.totalAmount.toFixed(2)}
                  </div>
                </div>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg mb-4">
                <div className="flex justify-between items-center">
                  <div>
                    <span className="block text-sm text-gray-600">Original Amount</span>
                    <span className="text-xl font-medium">
                      ${includeTax ? (parseFloat(amount) - result.taxAmount).toFixed(2) : parseFloat(amount).toFixed(2)}
                    </span>
                  </div>
                  <div className="text-center">
                    <span className="block text-sm text-gray-600">Tax ({parseFloat(taxRate)}%)</span>
                    <span className="text-xl font-medium">${result.taxAmount.toFixed(2)}</span>
                  </div>
                  <div className="text-right">
                    <span className="block text-sm text-gray-600">Final Amount</span>
                    <span className="text-xl font-medium">${includeTax ? parseFloat(amount).toFixed(2) : result.totalAmount.toFixed(2)}</span>
                  </div>
                </div>
              </div>
              
              <p className="text-sm text-gray-600">
                {includeTax 
                  ? `From a total of $${parseFloat(amount).toFixed(2)}, $${result.taxAmount.toFixed(2)} is tax (${parseFloat(taxRate)}%), and $${(parseFloat(amount) - result.taxAmount).toFixed(2)} is the pre-tax amount.`
                  : `Adding ${parseFloat(taxRate)}% tax ($${result.taxAmount.toFixed(2)}) to $${parseFloat(amount).toFixed(2)} results in a total of $${result.totalAmount.toFixed(2)}.`
                }
              </p>
            </div>
          )}
        </CardContent>
      </Card>
      
      <div className="prose max-w-none">
        <h2>Understanding GST and Sales Tax</h2>
        <p>
          Goods and Services Tax (GST) and Sales Tax are consumption taxes placed on most goods and services sold for domestic consumption. These taxes are paid by consumers but collected by businesses to be remitted to the government.
        </p>
        
        <h2>Two Ways to Calculate Tax</h2>
        <p>
          There are two common approaches to tax calculation:
        </p>
        <ul>
          <li><strong>Add Tax (Tax Exclusive):</strong> When you have a pre-tax amount and need to calculate the final price after adding tax</li>
          <li><strong>Remove Tax (Tax Inclusive):</strong> When you have a final price that already includes tax and need to calculate the original pre-tax amount</li>
        </ul>
        
        <h2>Common GST/VAT/Sales Tax Rates Around the World</h2>
        <ul>
          <li><strong>5%, 12%, 18%, 28%:</strong> India GST rates for different categories of goods and services</li>
          <li><strong>20%:</strong> United Kingdom VAT standard rate</li>
          <li><strong>10%:</strong> Australia GST rate</li>
          <li><strong>7-9%:</strong> Typical US state sales tax rates (varies by state and locality)</li>
          <li><strong>5%:</strong> Canada GST rate (additional provincial taxes may apply)</li>
          <li><strong>19%:</strong> Germany VAT standard rate</li>
        </ul>
        
        <h2>Tax Calculation Formulas</h2>
        <p>The mathematical formulas used by this calculator are:</p>
        <ul>
          <li><strong>Add Tax:</strong> Tax Amount = Original Amount × (Tax Rate ÷ 100)</li>
          <li><strong>Remove Tax:</strong> Tax Amount = Final Amount - [Final Amount ÷ (1 + (Tax Rate ÷ 100))]</li>
        </ul>
        
        <h2>When to Use This Calculator</h2>
        <ul>
          <li>Businesses calculating sales tax to add to customer invoices</li>
          <li>Consumers wanting to know the final price after tax</li>
          <li>Businesses extracting the pre-tax amount from inclusive prices</li>
          <li>Accounting reconciliation between tax-inclusive and tax-exclusive amounts</li>
          <li>International travelers estimating prices with different tax rates</li>
        </ul>
        
        <p>
          This calculator simplifies tax calculations, helping businesses comply with tax regulations and enabling consumers to understand the tax component of their purchases.
        </p>
      </div>
    </div>
  );
};

export default TaxCalculator;
