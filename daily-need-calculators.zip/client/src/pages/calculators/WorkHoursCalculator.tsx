import { useState, useEffect } from "react";
import { calculateWorkHours, WorkDay } from "@/utils/calculatorUtils";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const WorkHoursCalculator = () => {
  const [calculationType, setCalculationType] = useState<string>("daily");
  
  // Daily calculation state
  const [timeIn, setTimeIn] = useState<string>("");
  const [timeOut, setTimeOut] = useState<string>("");
  const [breakDuration, setBreakDuration] = useState<string>("0");
  const [dailyHours, setDailyHours] = useState<number>(0);
  
  // Weekly calculation state
  const [workDays, setWorkDays] = useState<WorkDay[]>([
    { id: "1", date: "", timeIn: "", timeOut: "", hoursWorked: 0 },
    { id: "2", date: "", timeIn: "", timeOut: "", hoursWorked: 0 },
    { id: "3", date: "", timeIn: "", timeOut: "", hoursWorked: 0 },
    { id: "4", date: "", timeIn: "", timeOut: "", hoursWorked: 0 },
    { id: "5", date: "", timeIn: "", timeOut: "", hoursWorked: 0 }
  ]);
  const [totalWeeklyHours, setTotalWeeklyHours] = useState<number>(0);
  
  // Calculate daily hours
  const handleCalculateDailyHours = () => {
    if (!timeIn || !timeOut) return;
    
    const hoursWorked = calculateWorkHours(timeIn, timeOut);
    const breakHours = parseFloat(breakDuration) || 0;
    
    setDailyHours(Math.max(0, hoursWorked - breakHours));
  };
  
  // Calculate weekly hours
  const handleCalculateWeeklyHours = () => {
    const total = workDays.reduce((acc, day) => acc + day.hoursWorked, 0);
    setTotalWeeklyHours(total);
  };
  
  // Update work day
  const updateWorkDay = (id: string, field: keyof WorkDay, value: string) => {
    const updatedWorkDays = workDays.map(day => {
      if (day.id === id) {
        const updatedDay = { ...day, [field]: value };
        
        // Recalculate hours worked if time in or time out changes
        if (field === 'timeIn' || field === 'timeOut') {
          updatedDay.hoursWorked = calculateWorkHours(
            field === 'timeIn' ? value : day.timeIn,
            field === 'timeOut' ? value : day.timeOut
          );
        }
        
        return updatedDay;
      }
      return day;
    });
    
    setWorkDays(updatedWorkDays);
  };
  
  // Add work day
  const addWorkDay = () => {
    setWorkDays([
      ...workDays,
      { 
        id: (workDays.length + 1).toString(), 
        date: "", 
        timeIn: "", 
        timeOut: "", 
        hoursWorked: 0 
      }
    ]);
  };
  
  // Remove work day
  const removeWorkDay = (id: string) => {
    if (workDays.length <= 1) return;
    setWorkDays(workDays.filter(day => day.id !== id));
  };
  
  // Recalculate when inputs change
  useEffect(() => {
    handleCalculateDailyHours();
  }, [timeIn, timeOut, breakDuration]);
  
  useEffect(() => {
    handleCalculateWeeklyHours();
  }, [workDays]);

  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">Work Hours Calculator</h1>
      <p className="text-lg text-gray-600 mb-8">
        Track your daily or weekly working hours and calculate total time worked.
      </p>
      
      <Tabs defaultValue="daily" onValueChange={setCalculationType}>
        <TabsList className="mb-6">
          <TabsTrigger value="daily">Daily Calculator</TabsTrigger>
          <TabsTrigger value="weekly">Weekly Calculator</TabsTrigger>
        </TabsList>
        
        <TabsContent value="daily">
          <Card className="mb-8">
            <CardContent className="pt-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <div>
                  <Label htmlFor="timeIn" className="block text-sm font-medium text-gray-700 mb-1">
                    Time In
                  </Label>
                  <Input
                    type="time"
                    id="timeIn"
                    value={timeIn}
                    onChange={(e) => setTimeIn(e.target.value)}
                    className="w-full"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="timeOut" className="block text-sm font-medium text-gray-700 mb-1">
                    Time Out
                  </Label>
                  <Input
                    type="time"
                    id="timeOut"
                    value={timeOut}
                    onChange={(e) => setTimeOut(e.target.value)}
                    className="w-full"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="breakDuration" className="block text-sm font-medium text-gray-700 mb-1">
                    Break Duration (hours)
                  </Label>
                  <Input
                    type="number"
                    id="breakDuration"
                    value={breakDuration}
                    onChange={(e) => setBreakDuration(e.target.value)}
                    min="0"
                    step="0.25"
                    className="w-full"
                  />
                </div>
              </div>
              
              {(timeIn && timeOut) && (
                <div className="mt-6 border-t border-gray-200 pt-6">
                  <div className="bg-gray-50 p-6 rounded-lg text-center">
                    <div className="text-sm text-gray-600 mb-1">Total Hours Worked</div>
                    <div className="text-4xl font-bold text-primary-600">
                      {dailyHours.toFixed(2)}
                    </div>
                    <div className="text-sm text-gray-600 mt-2">
                      {dailyHours > 0 
                        ? `You worked for ${dailyHours.toFixed(2)} hours today.`
                        : "Please enter valid time in and time out values."
                      }
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="weekly">
          <Card className="mb-8">
            <CardContent className="pt-6">
              <div className="mb-6">
                <div className="grid grid-cols-12 gap-4 mb-2 font-medium text-sm text-gray-700">
                  <div className="col-span-3">Date</div>
                  <div className="col-span-3">Time In</div>
                  <div className="col-span-3">Time Out</div>
                  <div className="col-span-2">Hours</div>
                  <div className="col-span-1"></div>
                </div>
                
                {workDays.map((day, index) => (
                  <div key={day.id} className="grid grid-cols-12 gap-4 mb-4 items-center">
                    <div className="col-span-3">
                      <Input
                        type="date"
                        value={day.date}
                        onChange={(e) => updateWorkDay(day.id, 'date', e.target.value)}
                        className="w-full"
                      />
                    </div>
                    <div className="col-span-3">
                      <Input
                        type="time"
                        value={day.timeIn}
                        onChange={(e) => updateWorkDay(day.id, 'timeIn', e.target.value)}
                        className="w-full"
                      />
                    </div>
                    <div className="col-span-3">
                      <Input
                        type="time"
                        value={day.timeOut}
                        onChange={(e) => updateWorkDay(day.id, 'timeOut', e.target.value)}
                        className="w-full"
                      />
                    </div>
                    <div className="col-span-2 font-medium text-center">
                      {day.hoursWorked.toFixed(2)}
                    </div>
                    <div className="col-span-1 text-right">
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => removeWorkDay(day.id)}
                        disabled={workDays.length <= 1}
                        className="h-8 w-8 p-0"
                      >
                        <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                        </svg>
                        <span className="sr-only">Remove</span>
                      </Button>
                    </div>
                  </div>
                ))}
                
                <Button
                  type="button"
                  variant="outline"
                  onClick={addWorkDay}
                  className="mt-2"
                >
                  Add Row
                </Button>
              </div>
              
              <div className="mt-6 border-t border-gray-200 pt-6">
                <div className="bg-gray-50 p-6 rounded-lg text-center">
                  <div className="text-sm text-gray-600 mb-1">Total Weekly Hours</div>
                  <div className="text-4xl font-bold text-primary-600">
                    {totalWeeklyHours.toFixed(2)}
                  </div>
                  <div className="text-sm text-gray-600 mt-2">
                    {totalWeeklyHours > 0 
                      ? `You worked for a total of ${totalWeeklyHours.toFixed(2)} hours this week.`
                      : "Add your work schedule to calculate total hours."
                    }
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      <div className="prose max-w-none">
        <h2>Tracking Your Work Hours</h2>
        <p>
          Accurately tracking your work hours is essential for multiple reasons:
        </p>
        <ul>
          <li>Ensuring proper compensation for your time</li>
          <li>Maintaining a healthy work-life balance</li>
          <li>Meeting regulatory requirements for work hours</li>
          <li>Tracking productivity and project time allocation</li>
          <li>Billing clients accurately for time-based services</li>
        </ul>
        
        <h2>Daily vs. Weekly Tracking</h2>
        <p>
          The Work Hours Calculator provides two calculation methods to suit different needs:
        </p>
        <ul>
          <li><strong>Daily Calculator:</strong> Perfect for calculating a single work day's hours, including break deductions.</li>
          <li><strong>Weekly Calculator:</strong> Ideal for tracking your entire work week and seeing cumulative hours worked.</li>
        </ul>
        
        <h2>Understanding Overtime</h2>
        <p>
          In many jurisdictions, working more than 40 hours per week qualifies for overtime pay (typically 1.5x your regular rate). This calculator can help you track when you're approaching or exceeding overtime thresholds.
        </p>
        
        <h2>Tips for Accurate Time Tracking</h2>
        <ul>
          <li>Record your start and end times as soon as possible</li>
          <li>Be consistent with break tracking</li>
          <li>Use the same time format (12-hour or 24-hour) consistently</li>
          <li>Consider rounding to the nearest 15 minutes for simplicity</li>
          <li>Save or export your weekly hours for record-keeping</li>
        </ul>
        
        <p>
          Whether you're an employee tracking your hours for personal reference, a freelancer billing clients, or a manager monitoring team hours, this calculator provides a simple way to keep track of valuable work time.
        </p>
      </div>
    </div>
  );
};

export default WorkHoursCalculator;
