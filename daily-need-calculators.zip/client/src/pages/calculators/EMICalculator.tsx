import { useState, useEffect } from "react";
import { calculateEMI } from "@/utils/calculatorUtils";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Card, CardContent } from "@/components/ui/card";

const EMICalculator = () => {
  const [loanAmount, setLoanAmount] = useState<string>("100000");
  const [interestRate, setInterestRate] = useState<string>("10");
  const [loanTenure, setLoanTenure] = useState<string>("5");
  const [result, setResult] = useState<{
    monthlyEMI: number;
    totalInterest: number;
    totalPayment: number;
  } | null>(null);

  // Calculate EMI
  const handleCalculateEMI = () => {
    const principal = parseFloat(loanAmount) || 0;
    const rate = parseFloat(interestRate) || 0;
    const years = parseFloat(loanTenure) || 0;
    
    const result = calculateEMI(principal, rate, years);
    setResult(result);
  };

  // Recalculate when inputs change
  useEffect(() => {
    handleCalculateEMI();
  }, [loanAmount, interestRate, loanTenure]);

  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">EMI Calculator</h1>
      <p className="text-lg text-gray-600 mb-8">
        Calculate your Equated Monthly Installment (EMI) for personal, auto, or home loans.
      </p>
      
      <Card className="mb-8">
        <CardContent className="pt-6">
          <div className="mb-6">
            <Label htmlFor="loanAmount" className="block text-sm font-medium text-gray-700 mb-1">
              Loan Amount
            </Label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <span className="text-gray-500 sm:text-sm">₹</span>
              </div>
              <Input
                type="number"
                id="loanAmount"
                value={loanAmount}
                onChange={(e) => setLoanAmount(e.target.value)}
                min="1000"
                step="1000"
                className="w-full pl-7"
                required
              />
            </div>
            <Slider
              value={[parseFloat(loanAmount) || 0]}
              min={1000}
              max={1000000}
              step={1000}
              onValueChange={(value) => setLoanAmount(value[0].toString())}
              className="mt-4"
            />
            <div className="flex justify-between text-xs text-gray-500 mt-1">
              <span>₹1,000</span>
              <span>₹1,000,000</span>
            </div>
          </div>
          
          <div className="mb-6">
            <Label htmlFor="interestRate" className="block text-sm font-medium text-gray-700 mb-1">
              Interest Rate (% per annum)
            </Label>
            <div className="relative">
              <Input
                type="number"
                id="interestRate"
                value={interestRate}
                onChange={(e) => setInterestRate(e.target.value)}
                min="1"
                max="30"
                step="0.1"
                className="w-full pr-9"
                required
              />
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                <span className="text-gray-500 sm:text-sm">%</span>
              </div>
            </div>
            <Slider
              value={[parseFloat(interestRate) || 0]}
              min={1}
              max={30}
              step={0.1}
              onValueChange={(value) => setInterestRate(value[0].toString())}
              className="mt-4"
            />
            <div className="flex justify-between text-xs text-gray-500 mt-1">
              <span>1%</span>
              <span>30%</span>
            </div>
          </div>
          
          <div className="mb-6">
            <Label htmlFor="loanTenure" className="block text-sm font-medium text-gray-700 mb-1">
              Loan Tenure (years)
            </Label>
            <Input
              type="number"
              id="loanTenure"
              value={loanTenure}
              onChange={(e) => setLoanTenure(e.target.value)}
              min="1"
              max="30"
              step="1"
              className="w-full"
              required
            />
            <Slider
              value={[parseFloat(loanTenure) || 0]}
              min={1}
              max={30}
              step={1}
              onValueChange={(value) => setLoanTenure(value[0].toString())}
              className="mt-4"
            />
            <div className="flex justify-between text-xs text-gray-500 mt-1">
              <span>1 year</span>
              <span>30 years</span>
            </div>
          </div>
          
          {result && parseFloat(loanAmount) > 0 && parseFloat(interestRate) > 0 && parseFloat(loanTenure) > 0 && (
            <div className="mt-6 border-t border-gray-200 pt-6">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <div className="text-sm text-gray-600 mb-1">Monthly EMI</div>
                  <div className="text-3xl font-bold text-primary-600">
                    ₹{result.monthlyEMI.toFixed(2)}
                  </div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <div className="text-sm text-gray-600 mb-1">Total Interest</div>
                  <div className="text-3xl font-bold text-primary-600">
                    ₹{result.totalInterest.toFixed(2)}
                  </div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <div className="text-sm text-gray-600 mb-1">Total Payment</div>
                  <div className="text-3xl font-bold text-primary-600">
                    ₹{result.totalPayment.toFixed(2)}
                  </div>
                </div>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg mb-4">
                <div className="h-6 w-full bg-gray-200 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-primary-500" 
                    style={{ 
                      width: `${(parseFloat(loanAmount) / result.totalPayment) * 100}%`
                    }}
                  ></div>
                </div>
                <div className="flex justify-between mt-2 text-sm">
                  <div>
                    <span className="inline-block w-3 h-3 bg-primary-500 rounded-full mr-1"></span>
                    Principal: ₹{parseFloat(loanAmount).toFixed(2)} ({((parseFloat(loanAmount) / result.totalPayment) * 100).toFixed(1)}%)
                  </div>
                  <div>
                    <span className="inline-block w-3 h-3 bg-gray-300 rounded-full mr-1"></span>
                    Interest: ₹{result.totalInterest.toFixed(2)} ({((result.totalInterest / result.totalPayment) * 100).toFixed(1)}%)
                  </div>
                </div>
              </div>
              
              <p className="text-sm text-gray-600">
                For a loan amount of ₹{parseFloat(loanAmount).toLocaleString()} at {parseFloat(interestRate)}% interest for {parseFloat(loanTenure)} years, 
                your monthly EMI will be ₹{result.monthlyEMI.toFixed(2)}. You will pay ₹{result.totalInterest.toFixed(2)} as interest over the life of the loan.
              </p>
            </div>
          )}
        </CardContent>
      </Card>
      
      <div className="prose max-w-none">
        <h2>Understanding EMI (Equated Monthly Installment)</h2>
        <p>
          EMI is a fixed payment amount made by a borrower to a lender at a specified date each month. EMIs are used to pay off both the interest and principal each month so that over a specified time period, the loan is paid off in full.
        </p>
        
        <h2>The EMI Formula</h2>
        <p>
          The mathematical formula for calculating EMI is:
        </p>
        <p className="bg-gray-50 p-4 text-center">
          EMI = P × r × (1 + r)^n / ((1 + r)^n - 1)
        </p>
        <p>Where:</p>
        <ul>
          <li><strong>P</strong> = Principal loan amount</li>
          <li><strong>r</strong> = Monthly interest rate (annual interest rate ÷ 12 ÷ 100)</li>
          <li><strong>n</strong> = Total number of monthly payments (loan tenure in years × 12)</li>
        </ul>
        
        <h2>Factors Affecting Your EMI</h2>
        <ul>
          <li><strong>Loan Amount:</strong> Higher loan amounts result in higher EMIs</li>
          <li><strong>Interest Rate:</strong> Higher interest rates increase your EMI</li>
          <li><strong>Loan Tenure:</strong> Longer loan tenures reduce your monthly EMI but increase the total interest paid</li>
          <li><strong>Down Payment:</strong> A larger down payment reduces the loan amount and subsequently the EMI</li>
        </ul>
        
        <h2>Different Types of Loans</h2>
        <ul>
          <li><strong>Home Loans:</strong> Typically have lower interest rates and longer tenures (15-30 years)</li>
          <li><strong>Auto Loans:</strong> Usually have moderate interest rates and medium-length tenures (3-7 years)</li>
          <li><strong>Personal Loans:</strong> Often have higher interest rates and shorter tenures (1-5 years)</li>
          <li><strong>Education Loans:</strong> May have special interest rates and repayment terms</li>
        </ul>
        
        <h2>Tips for Managing Your Loan</h2>
        <ul>
          <li>Make a larger down payment if possible to reduce the principal amount</li>
          <li>Compare interest rates from multiple lenders before finalizing</li>
          <li>Consider a shorter loan tenure if you can afford higher EMIs to save on total interest</li>
          <li>Make partial prepayments whenever possible to reduce the outstanding principal</li>
          <li>Ensure your EMI doesn't exceed 40-50% of your monthly income to maintain financial stability</li>
        </ul>
        
        <p>
          This EMI calculator helps you plan your loan repayment effectively by showing exactly how much you'll pay monthly and the total cost over the loan's lifetime.
        </p>
      </div>
    </div>
  );
};

export default EMICalculator;
