import { useState, useEffect } from "react";
import { conversionData, unitLabels } from "@/utils/calculatorUtils";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";

type ConversionCategory = "length" | "weight" | "volume" | "temperature" | "area" | "speed";

const UnitConverter = () => {
  const [category, setCategory] = useState<ConversionCategory>("length");
  const [fromValue, setFromValue] = useState<string>("");
  const [fromUnit, setFromUnit] = useState<string>("m");
  const [toUnit, setToUnit] = useState<string>("km");
  const [toValue, setToValue] = useState<string>("");
  const [conversionExplanation, setConversionExplanation] = useState<string>("Enter a value to see conversion details.");
  const [commonConversions, setCommonConversions] = useState<Array<{ from: string; to: string; result: number }>>([]);

  // Handle category change
  const handleCategoryChange = (value: string) => {
    setCategory(value as ConversionCategory);
    
    // Reset units based on new category
    const units = Object.keys(unitLabels[value as ConversionCategory]);
    setFromUnit(units[0]);
    setToUnit(units.length > 1 ? units[1] : units[0]);
    
    // Clear values and explanations
    setFromValue("");
    setToValue("");
    setConversionExplanation("Enter a value to see conversion details.");
    setCommonConversions([]);
  };

  // Convert units
  const convertUnits = () => {
    const value = parseFloat(fromValue) || 0;
    
    if (value <= 0 && category !== 'temperature') {
      setToValue("");
      setConversionExplanation("Enter a value to see conversion details.");
      setCommonConversions([]);
      return;
    }
    
    let result: number;
    
    // Handle temperature conversions (which use functions)
    if (category === 'temperature') {
      if (fromUnit === toUnit) {
        result = value;
      } else if (typeof conversionData[category][fromUnit][toUnit] === 'function') {
        result = conversionData[category][fromUnit][toUnit](value);
      } else {
        result = value * (conversionData[category][fromUnit][toUnit] as number);
      }
    } else {
      const fromToRate = (conversionData[category][fromUnit as string] as Record<string, number>)[toUnit];
      result = value * fromToRate;
    }
    
    // Display result
    setToValue(result.toFixed(4));
    
    // Show explanation
    let explanation: string;
    if (category === 'temperature') {
      explanation = `${value} ${unitLabels[category][fromUnit].replace(/ \(.+\)/, '')} = ${result.toFixed(2)} ${unitLabels[category][toUnit].replace(/ \(.+\)/, '')}`;
    } else {
      explanation = `${value} ${unitLabels[category][fromUnit].replace(/ \(.+\)/, '')} = ${result.toFixed(4)} ${unitLabels[category][toUnit].replace(/ \(.+\)/, '')}`;
    }
    setConversionExplanation(explanation);
    
    // Show common conversions
    populateCommonConversions(value);
  };

  // Populate common conversions
  const populateCommonConversions = (value: number) => {
    const units = Object.keys(unitLabels[category]);
    const conversions: Array<{ from: string; to: string; result: number }> = [];
    
    units.forEach(to => {
      if (to !== fromUnit) {
        let result: number;
        
        if (category === 'temperature') {
          if (typeof conversionData[category][fromUnit][to] === 'function') {
            result = conversionData[category][fromUnit][to](value);
          } else {
            result = value * (conversionData[category][fromUnit][to] as number);
          }
        } else {
          const fromToRate = (conversionData[category][fromUnit as string] as Record<string, number>)[to];
          result = value * fromToRate;
        }
        
        conversions.push({
          from: unitLabels[category][fromUnit].replace(/ \(.+\)/, ''),
          to: unitLabels[category][to].replace(/ \(.+\)/, ''),
          result: result
        });
      }
    });
    
    setCommonConversions(conversions);
  };

  // Swap units
  const handleSwapUnits = () => {
    const tempUnit = fromUnit;
    const tempValue = fromValue;
    
    setFromUnit(toUnit);
    setToUnit(tempUnit);
    setFromValue(toValue);
    
    convertUnits();
  };

  // Recalculate when inputs change
  useEffect(() => {
    convertUnits();
  }, [fromValue, fromUnit, toUnit, category]);

  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">Unit Converter</h1>
      <p className="text-lg text-gray-600 mb-8">
        Convert between different units of measurement in real-time.
      </p>
      
      <Card className="mb-8">
        <CardContent className="pt-6">
          <div className="mb-6">
            <Label htmlFor="conversionCategory" className="block text-sm font-medium text-gray-700 mb-1">
              Conversion Category
            </Label>
            <Select 
              value={category} 
              onValueChange={handleCategoryChange}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select a category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="length">Length</SelectItem>
                <SelectItem value="weight">Weight/Mass</SelectItem>
                <SelectItem value="volume">Volume</SelectItem>
                <SelectItem value="temperature">Temperature</SelectItem>
                <SelectItem value="area">Area</SelectItem>
                <SelectItem value="speed">Speed</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <Label htmlFor="fromValue" className="block text-sm font-medium text-gray-700 mb-1">
                From
              </Label>
              <div className="flex">
                <Input
                  type="number"
                  id="fromValue"
                  value={fromValue}
                  onChange={(e) => setFromValue(e.target.value)}
                  min="0"
                  step="any"
                  placeholder="0"
                  className="flex-1 rounded-r-none"
                  required
                />
                <Select 
                  value={fromUnit} 
                  onValueChange={setFromUnit}
                >
                  <SelectTrigger className="rounded-l-none w-[120px] min-w-[120px]">
                    <SelectValue placeholder="Unit" />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(unitLabels[category]).map(([code, label]) => (
                      <SelectItem key={code} value={code}>{label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label htmlFor="toValue" className="block text-sm font-medium text-gray-700 mb-1">
                To
              </Label>
              <div className="flex">
                <Input
                  type="number"
                  id="toValue"
                  value={toValue}
                  readOnly
                  className="flex-1 rounded-r-none bg-gray-50"
                  placeholder="Result"
                />
                <Select 
                  value={toUnit} 
                  onValueChange={setToUnit}
                >
                  <SelectTrigger className="rounded-l-none w-[120px] min-w-[120px]">
                    <SelectValue placeholder="Unit" />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(unitLabels[category]).map(([code, label]) => (
                      <SelectItem key={code} value={code}>{label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          
          <Button
            type="button"
            variant="outline"
            onClick={handleSwapUnits}
            className="flex items-center justify-center"
          >
            <svg className="h-4 w-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4"></path>
            </svg>
            Swap Units
          </Button>
          
          <div className="mt-6 border-t border-gray-200 pt-6">
            <p className="text-sm text-gray-600">{conversionExplanation}</p>
            
            {commonConversions.length > 0 && (
              <div className="mt-4 overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Common Conversions
                      </th>
                      <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Value
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {commonConversions.map((conversion, index) => (
                      <tr key={index}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                          {parseFloat(fromValue)} {conversion.from} to {conversion.to}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700 text-right">
                          {conversion.result.toFixed(4)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
      
      <div className="prose max-w-none">
        <h2>Understanding Unit Conversion</h2>
        <p>
          Unit conversion is the process of converting a measurement from one unit to another. This is essential in science, engineering, cooking, travel, and many other everyday situations where measurements need to be expressed in different units.
        </p>
        
        <h2>Common Conversion Categories</h2>
        <ul>
          <li><strong>Length:</strong> Converting between meters, kilometers, inches, feet, etc.</li>
          <li><strong>Weight/Mass:</strong> Converting between kilograms, grams, pounds, ounces, etc.</li>
          <li><strong>Volume:</strong> Converting between liters, milliliters, gallons, cups, etc.</li>
          <li><strong>Temperature:</strong> Converting between Celsius, Fahrenheit, and Kelvin</li>
          <li><strong>Area:</strong> Converting between square meters, acres, square feet, etc.</li>
          <li><strong>Speed:</strong> Converting between mph, km/h, m/s, knots, etc.</li>
        </ul>
        
        <h2>When Unit Conversion Is Useful</h2>
        <p>
          Unit conversion is valuable in many scenarios:
        </p>
        <ul>
          <li>Following recipes with different measurement systems</li>
          <li>Understanding weather forecasts when traveling internationally</li>
          <li>Converting measurements for home improvement projects</li>
          <li>Understanding fuel efficiency when renting vehicles abroad</li>
          <li>Converting clothing and shoe sizes between different countries</li>
        </ul>
        
        <p>
          This unit converter tool supports multiple categories of measurements and provides instant, accurate conversions to help you work with different measurement systems effortlessly.
        </p>
      </div>
    </div>
  );
};

export default UnitConverter;
