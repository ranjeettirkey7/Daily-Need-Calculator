import { useState, useEffect } from "react";
import { calculateFuelCost } from "@/utils/calculatorUtils";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";

const FuelCostCalculator = () => {
  const [distance, setDistance] = useState<string>("");
  const [distanceUnit, setDistanceUnit] = useState<string>("miles");
  const [fuelEfficiency, setFuelEfficiency] = useState<string>("");
  const [efficiencyUnit, setEfficiencyUnit] = useState<string>("mpg");
  const [fuelPrice, setFuelPrice] = useState<string>("");
  const [result, setResult] = useState<{
    fuelAmount: number;
    totalCost: number;
  } | null>(null);

  // Calculate fuel cost
  const handleCalculateFuelCost = () => {
    const distanceValue = parseFloat(distance) || 0;
    const efficiencyValue = parseFloat(fuelEfficiency) || 0;
    const priceValue = parseFloat(fuelPrice) || 0;
    
    // Convert units if necessary
    let convertedDistance = distanceValue;
    let convertedEfficiency = efficiencyValue;
    
    if (distanceUnit === "kilometers" && efficiencyUnit === "mpg") {
      // Convert km to miles for MPG calculation
      convertedDistance = distanceValue * 0.621371;
    } else if (distanceUnit === "miles" && efficiencyUnit === "kpl") {
      // Convert miles to km for KPL calculation
      convertedDistance = distanceValue * 1.60934;
    }
    
    if (efficiencyUnit === "kpl" && distanceUnit === "miles") {
      // Convert KPL to MPG
      convertedEfficiency = efficiencyValue * 2.35215;
    } else if (efficiencyUnit === "mpg" && distanceUnit === "kilometers") {
      // Convert MPG to KPL
      convertedEfficiency = efficiencyValue * 0.425144;
    }
    
    const result = calculateFuelCost(convertedDistance, convertedEfficiency, priceValue);
    setResult(result);
  };

  // Recalculate when inputs change
  useEffect(() => {
    handleCalculateFuelCost();
  }, [distance, distanceUnit, fuelEfficiency, efficiencyUnit, fuelPrice]);

  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">Fuel Cost Calculator</h1>
      <p className="text-lg text-gray-600 mb-8">
        Calculate the estimated travel cost based on fuel price, distance, and mileage.
      </p>
      
      <Card className="mb-8">
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <Label htmlFor="distance" className="block text-sm font-medium text-gray-700 mb-1">
                Distance
              </Label>
              <div className="flex">
                <Input
                  type="number"
                  id="distance"
                  value={distance}
                  onChange={(e) => setDistance(e.target.value)}
                  min="0"
                  step="any"
                  placeholder="0"
                  className="flex-1 rounded-r-none"
                  required
                />
                <Select
                  value={distanceUnit}
                  onValueChange={setDistanceUnit}
                >
                  <SelectTrigger className="rounded-l-none w-[120px] min-w-[120px]">
                    <SelectValue placeholder="Unit" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="miles">Miles</SelectItem>
                    <SelectItem value="kilometers">Kilometers</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label htmlFor="fuelEfficiency" className="block text-sm font-medium text-gray-700 mb-1">
                Fuel Efficiency
              </Label>
              <div className="flex">
                <Input
                  type="number"
                  id="fuelEfficiency"
                  value={fuelEfficiency}
                  onChange={(e) => setFuelEfficiency(e.target.value)}
                  min="0"
                  step="any"
                  placeholder="0"
                  className="flex-1 rounded-r-none"
                  required
                />
                <Select
                  value={efficiencyUnit}
                  onValueChange={setEfficiencyUnit}
                >
                  <SelectTrigger className="rounded-l-none w-[120px] min-w-[120px]">
                    <SelectValue placeholder="Unit" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="mpg">Miles per Gallon</SelectItem>
                    <SelectItem value="kpl">Kilometers per Liter</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          
          <div className="mb-6">
            <Label htmlFor="fuelPrice" className="block text-sm font-medium text-gray-700 mb-1">
              Fuel Price
            </Label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <span className="text-gray-500 sm:text-sm">₹</span>
              </div>
              <Input
                type="number"
                id="fuelPrice"
                value={fuelPrice}
                onChange={(e) => setFuelPrice(e.target.value)}
                min="0"
                step="0.01"
                placeholder="0.00"
                className="w-full pl-7"
                required
              />
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                <span className="text-gray-500 sm:text-sm">per {efficiencyUnit === "mpg" ? "gallon" : "liter"}</span>
              </div>
            </div>
          </div>
          
          {result && parseFloat(distance) > 0 && parseFloat(fuelEfficiency) > 0 && parseFloat(fuelPrice) > 0 && (
            <div className="mt-6 border-t border-gray-200 pt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <div className="text-sm text-gray-600 mb-1">Fuel Needed</div>
                  <div className="text-3xl font-bold text-primary-600">
                    {result.fuelAmount.toFixed(2)} {efficiencyUnit === "mpg" ? "gallons" : "liters"}
                  </div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <div className="text-sm text-gray-600 mb-1">Total Cost</div>
                  <div className="text-3xl font-bold text-primary-600">
                    ₹{result.totalCost.toFixed(2)}
                  </div>
                </div>
              </div>
              
              <p className="mt-4 text-sm text-gray-600">
                {`To travel ${distance} ${distanceUnit} with a fuel efficiency of ${fuelEfficiency} ${efficiencyUnit} and a fuel price of ₹${fuelPrice} per ${efficiencyUnit === "mpg" ? "gallon" : "liter"}, you'll need approximately ${result.fuelAmount.toFixed(2)} ${efficiencyUnit === "mpg" ? "gallons" : "liters"} of fuel, costing a total of ₹${result.totalCost.toFixed(2)}.`}
              </p>
            </div>
          )}
        </CardContent>
      </Card>
      
      <div className="prose max-w-none">
        <h2>Understanding Fuel Costs</h2>
        <p>
          Calculating fuel costs is essential for budgeting road trips, daily commutes, or estimating transportation expenses. This calculator helps you predict how much you'll spend on fuel for a given journey.
        </p>
        
        <h2>How Fuel Efficiency Works</h2>
        <p>
          Fuel efficiency is typically measured in:
        </p>
        <ul>
          <li><strong>Miles per Gallon (MPG):</strong> The number of miles a vehicle can travel on one gallon of fuel (common in the US)</li>
          <li><strong>Kilometers per Liter (KPL):</strong> The number of kilometers a vehicle can travel on one liter of fuel (common internationally)</li>
          <li><strong>Liters per 100 Kilometers (L/100km):</strong> The amount of fuel needed to travel 100 kilometers (common in Europe)</li>
        </ul>
        
        <h2>Factors Affecting Fuel Consumption</h2>
        <p>
          Several factors can influence your actual fuel consumption and cost:
        </p>
        <ul>
          <li>Driving habits (acceleration, braking, speed)</li>
          <li>Vehicle maintenance status</li>
          <li>Road conditions and terrain</li>
          <li>Weather conditions</li>
          <li>Vehicle load (passengers and cargo)</li>
          <li>Traffic conditions</li>
        </ul>
        
        <h2>How to Use This Fuel Cost Calculator</h2>
        <ol>
          <li>Enter the distance you plan to travel</li>
          <li>Select the appropriate distance unit (miles or kilometers)</li>
          <li>Input your vehicle's fuel efficiency</li>
          <li>Select the appropriate efficiency unit (MPG or KPL)</li>
          <li>Enter the current fuel price per gallon or liter</li>
          <li>View the estimated fuel amount needed and total cost</li>
        </ol>
        
        <p>
          This calculator is useful for planning travel budgets, comparing vehicle costs, or determining if carpooling might be more economical.
        </p>
      </div>
    </div>
  );
};

export default FuelCostCalculator;
