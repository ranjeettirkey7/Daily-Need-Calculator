import { useState, useEffect } from "react";
import { calculateDiscount } from "@/utils/calculatorUtils";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

const DiscountCalculator = () => {
  const [originalPrice, setOriginalPrice] = useState<string>("");
  const [discountPercentage, setDiscountPercentage] = useState<string>("");
  const [result, setResult] = useState<{
    savingsAmount: number;
    finalPrice: number;
    percentageSaved: number;
  } | null>(null);

  // Calculate discount
  const handleCalculateDiscount = () => {
    const price = parseFloat(originalPrice) || 0;
    const discount = parseFloat(discountPercentage) || 0;
    
    const result = calculateDiscount(price, discount);
    setResult(result);
  };

  // Recalculate when inputs change
  useEffect(() => {
    handleCalculateDiscount();
  }, [originalPrice, discountPercentage]);

  // Handle preset discount percentages
  const handleDiscountPreset = (percentage: number) => {
    setDiscountPercentage(percentage.toString());
  };

  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">Discount Calculator</h1>
      <p className="text-lg text-gray-600 mb-8">
        Calculate the final price and savings amount after applying a discount percentage.
      </p>
      
      <Card className="mb-8">
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <Label htmlFor="originalPrice" className="block text-sm font-medium text-gray-700 mb-1">
                Original Price
              </Label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <span className="text-gray-500 sm:text-sm">₹</span>
                </div>
                <Input
                  type="number"
                  id="originalPrice"
                  value={originalPrice}
                  onChange={(e) => setOriginalPrice(e.target.value)}
                  min="0"
                  step="0.01"
                  placeholder="0.00"
                  className="w-full pl-7"
                  required
                />
              </div>
            </div>
            <div>
              <Label htmlFor="discountPercentage" className="block text-sm font-medium text-gray-700 mb-1">
                Discount Percentage
              </Label>
              <div className="relative">
                <Input
                  type="number"
                  id="discountPercentage"
                  value={discountPercentage}
                  onChange={(e) => setDiscountPercentage(e.target.value)}
                  min="0"
                  max="100"
                  step="1"
                  placeholder="0"
                  className="w-full pr-9"
                  required
                />
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                  <span className="text-gray-500 sm:text-sm">%</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex space-x-4 mb-6">
            {[10, 15, 20, 25, 50].map((percentage) => (
              <Button
                key={percentage}
                type="button"
                variant="outline"
                onClick={() => handleDiscountPreset(percentage)}
                className={`py-1 px-3 ${
                  discountPercentage === percentage.toString() ? 'bg-primary-100 text-primary-700 border-primary-300' : ''
                }`}
              >
                {percentage}%
              </Button>
            ))}
          </div>
          
          {result && parseFloat(originalPrice) > 0 && (
            <div className="mt-6 border-t border-gray-200 pt-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <div className="text-sm text-gray-600 mb-1">Discount Amount</div>
                  <div className="text-3xl font-bold text-primary-600">
                    ₹{result.savingsAmount.toFixed(2)}
                  </div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <div className="text-sm text-gray-600 mb-1">Final Price</div>
                  <div className="text-3xl font-bold text-primary-600">
                    ₹{result.finalPrice.toFixed(2)}
                  </div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <div className="text-sm text-gray-600 mb-1">You Save</div>
                  <div className="text-3xl font-bold text-green-600">
                    {result.percentageSaved}%
                  </div>
                </div>
              </div>
              
              <p className="mt-4 text-sm text-gray-600">
                {parseFloat(discountPercentage) > 0 && parseFloat(originalPrice) > 0 &&
                  `You save ₹${result.savingsAmount.toFixed(2)} on a ₹${parseFloat(originalPrice).toFixed(2)} item at ${result.percentageSaved}% discount.`
                }
              </p>
            </div>
          )}
        </CardContent>
      </Card>
      
      <div className="prose max-w-none">
        <h2>Understanding Discounts</h2>
        <p>
          A discount is a reduction in the original price of a product or service, typically expressed as a percentage. Discounts are commonly offered during sales, promotions, or as incentives for customers.
        </p>
        
        <h2>Types of Discounts</h2>
        <ul>
          <li><strong>Percentage Discounts:</strong> A percentage reduction from the original price</li>
          <li><strong>Fixed Amount Discounts:</strong> A specific amount in rupees deducted from the price</li>
          <li><strong>Buy One Get One (BOGO):</strong> Purchase one item and receive another at a reduced price or free</li>
          <li><strong>Volume Discounts:</strong> Reduced prices when buying in larger quantities</li>
          <li><strong>Seasonal Discounts:</strong> Price reductions during specific times of the year</li>
        </ul>
        
        <h2>How to Use This Discount Calculator</h2>
        <ol>
          <li>Enter the original price of the item</li>
          <li>Input the discount percentage (or use the quick preset buttons)</li>
          <li>Instantly see the discount amount, final price, and percentage saved</li>
        </ol>
        
        <h2>Benefits of Calculating Discounts</h2>
        <p>
          Using a discount calculator helps you:
        </p>
        <ul>
          <li>Quickly determine if a sale item is a good deal</li>
          <li>Compare discounts across different products</li>
          <li>Budget more effectively by knowing your final costs</li>
          <li>Avoid mental math errors when shopping</li>
        </ul>
        
        <p>
          Whether you're shopping sales, planning a budget, or just curious about potential savings, this discount calculator provides fast, accurate results to help you make informed financial decisions.
        </p>
      </div>
    </div>
  );
};

export default DiscountCalculator;
