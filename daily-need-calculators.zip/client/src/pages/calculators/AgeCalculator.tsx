import { useState, useEffect } from "react";
import { calculateAge } from "@/utils/calculatorUtils";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent } from "@/components/ui/card";

const AgeCalculator = () => {
  const [birthDate, setBirthDate] = useState<string>("");
  const [calculationDate, setCalculationDate] = useState<string>(new Date().toISOString().split("T")[0]);
  const [showAdditionalUnits, setShowAdditionalUnits] = useState<boolean>(false);
  const [ageResult, setAgeResult] = useState<{
    years: number;
    months: number;
    days: number;
    totalDays: number;
    totalWeeks: number;
    totalHours: number;
  } | null>(null);

  // Calculate age function
  const handleCalculateAge = () => {
    if (!birthDate) return;

    const birthDateObj = new Date(birthDate);
    const calculationDateObj = calculationDate ? new Date(calculationDate) : new Date();
    
    const result = calculateAge(birthDateObj, calculationDateObj);
    setAgeResult(result);
  };

  // Recalculate when inputs change
  useEffect(() => {
    handleCalculateAge();
  }, [birthDate, calculationDate, showAdditionalUnits]);

  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">Age Calculator</h1>
      <p className="text-lg text-gray-600 mb-8">
        Calculate your exact age in years, months, and days from your date of birth to today or any other date.
      </p>
      
      <Card className="mb-8">
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <Label htmlFor="birthDate" className="block text-sm font-medium text-gray-700 mb-1">
                Date of Birth
              </Label>
              <Input
                type="date"
                id="birthDate"
                value={birthDate}
                onChange={(e) => setBirthDate(e.target.value)}
                className="w-full"
                required
              />
            </div>
            <div>
              <Label htmlFor="calculationDate" className="block text-sm font-medium text-gray-700 mb-1">
                Calculate To (default: today)
              </Label>
              <Input
                type="date"
                id="calculationDate"
                value={calculationDate}
                onChange={(e) => setCalculationDate(e.target.value)}
                className="w-full"
              />
            </div>
          </div>
          
          <div className="flex items-center mb-6">
            <Checkbox
              id="showAdditionalUnits"
              checked={showAdditionalUnits}
              onCheckedChange={(checked) => setShowAdditionalUnits(checked as boolean)}
            />
            <Label htmlFor="showAdditionalUnits" className="ml-2 block text-sm text-gray-700">
              Show additional time units (weeks, hours)
            </Label>
          </div>
          
          {ageResult && (
            <div className="mt-6 border-t border-gray-200 pt-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Your Age Is:</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <div className="text-4xl font-bold text-primary-600">{ageResult.years}</div>
                  <div className="text-sm text-gray-600">Years</div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <div className="text-4xl font-bold text-primary-600">{ageResult.months}</div>
                  <div className="text-sm text-gray-600">Months</div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <div className="text-4xl font-bold text-primary-600">{ageResult.days}</div>
                  <div className="text-sm text-gray-600">Days</div>
                </div>
              </div>
              
              {showAdditionalUnits && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-gray-50 p-4 rounded-lg text-center">
                    <div className="text-2xl font-bold text-primary-600">{ageResult.totalWeeks.toLocaleString()}</div>
                    <div className="text-sm text-gray-600">Total Weeks</div>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg text-center">
                    <div className="text-2xl font-bold text-primary-600">{ageResult.totalHours.toLocaleString()}</div>
                    <div className="text-sm text-gray-600">Total Hours</div>
                  </div>
                </div>
              )}
              
              <p className="mt-4 text-sm text-gray-600">
                {birthDate && `You were born on ${new Date(birthDate).toLocaleDateString()} and as of ${new Date(calculationDate).toLocaleDateString()}, you are ${ageResult.years} years, ${ageResult.months} months, and ${ageResult.days} days old.`}
              </p>
            </div>
          )}
        </CardContent>
      </Card>
      
      <div className="prose max-w-none">
        <h2>Understanding Age Calculation</h2>
        <p>
          Age calculation seems straightforward, but calculating exact age in years, months, and days requires careful consideration of varying month lengths and leap years. Our age calculator handles these complexities automatically.
        </p>
        <p>
          Years represent complete orbits around the sun since your birth. Months count the remaining time after complete years, acknowledging that months vary in length. Days account for the remainder after counting complete months.
        </p>
        
        <h2>Why Calculate Your Exact Age?</h2>
        <ul>
          <li>Legal requirements for age-specific services or benefits</li>
          <li>Precise age determination for medical purposes</li>
          <li>Celebrating "milestone" days like being exactly 10,000 days old</li>
          <li>Personal curiosity about your age in different time units</li>
        </ul>
        
        <h2>How to Use This Age Calculator</h2>
        <ol>
          <li>Enter your date of birth in the first field</li>
          <li>Keep the second field as today's date or select a different calculation date</li>
          <li>Check the box to see additional units like weeks and hours</li>
          <li>View your exact age broken down into years, months, and days</li>
        </ol>
        
        <p>
          The calculator automatically updates the results as you change any input, giving you real-time feedback as you explore different dates.
        </p>
      </div>
    </div>
  );
};

export default AgeCalculator;
