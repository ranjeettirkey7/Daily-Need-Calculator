import { useState, useEffect } from "react";
import { calculateTip } from "@/utils/calculatorUtils";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

const TipCalculator = () => {
  const [billAmount, setBillAmount] = useState<string>("");
  const [tipPercentage, setTipPercentage] = useState<string>("15");
  const [splitBetween, setSplitBetween] = useState<number>(1);
  const [result, setResult] = useState<{
    tipAmount: number;
    totalAmount: number;
    perPersonAmount: number;
  } | null>(null);

  // Calculate tip
  const handleCalculateTip = () => {
    const bill = parseFloat(billAmount) || 0;
    const tip = parseFloat(tipPercentage) || 0;
    
    const result = calculateTip(bill, tip, splitBetween);
    setResult(result);
  };

  // Recalculate when inputs change
  useEffect(() => {
    handleCalculateTip();
  }, [billAmount, tipPercentage, splitBetween]);

  // Handle preset tip percentages
  const handleTipPreset = (percentage: number) => {
    setTipPercentage(percentage.toString());
  };

  // Handle increment/decrement people
  const decrementPeople = () => {
    if (splitBetween > 1) {
      setSplitBetween(splitBetween - 1);
    }
  };

  const incrementPeople = () => {
    setSplitBetween(splitBetween + 1);
  };

  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">Tip Calculator</h1>
      <p className="text-lg text-gray-600 mb-8">
        Calculate tip amount and total bill based on bill amount and tip percentage.
      </p>
      
      <Card className="mb-8">
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <Label htmlFor="billAmount" className="block text-sm font-medium text-gray-700 mb-1">
                Bill Amount
              </Label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <span className="text-gray-500 sm:text-sm">₹</span>
                </div>
                <Input
                  type="number"
                  id="billAmount"
                  value={billAmount}
                  onChange={(e) => setBillAmount(e.target.value)}
                  min="0"
                  step="0.01"
                  placeholder="0.00"
                  className="w-full pl-7"
                  required
                />
              </div>
            </div>
            <div>
              <Label htmlFor="tipPercentage" className="block text-sm font-medium text-gray-700 mb-1">
                Tip Percentage
              </Label>
              <div className="relative">
                <Input
                  type="number"
                  id="tipPercentage"
                  value={tipPercentage}
                  onChange={(e) => setTipPercentage(e.target.value)}
                  min="0"
                  max="100"
                  step="1"
                  placeholder="15"
                  className="w-full pr-9"
                  required
                />
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                  <span className="text-gray-500 sm:text-sm">%</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mb-6">
            <Label htmlFor="splitBetween" className="block text-sm font-medium text-gray-700 mb-1">
              Split Between
            </Label>
            <div className="flex items-center">
              <Button 
                type="button" 
                variant="outline" 
                onClick={decrementPeople}
                className="px-3 py-1 rounded-l-md"
              >
                -
              </Button>
              <Input
                type="number"
                id="splitBetween"
                value={splitBetween}
                onChange={(e) => setSplitBetween(parseInt(e.target.value) || 1)}
                min="1"
                className="w-20 text-center rounded-none border-l-0 border-r-0"
              />
              <Button 
                type="button" 
                variant="outline" 
                onClick={incrementPeople}
                className="px-3 py-1 rounded-r-md"
              >
                +
              </Button>
              <span className="ml-2 text-sm text-gray-600">person(s)</span>
            </div>
          </div>
          
          <div className="flex space-x-4 mb-6">
            {[10, 15, 18, 20, 25].map((percentage) => (
              <Button
                key={percentage}
                type="button"
                variant="outline"
                onClick={() => handleTipPreset(percentage)}
                className={`py-1 px-3 ${
                  tipPercentage === percentage.toString() ? 'bg-primary-100 text-primary-700 border-primary-300' : ''
                }`}
              >
                {percentage}%
              </Button>
            ))}
          </div>
          
          {result && parseFloat(billAmount) > 0 && (
            <div className="mt-6 border-t border-gray-200 pt-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <div className="text-sm text-gray-600 mb-1">Tip Amount</div>
                  <div className="text-3xl font-bold text-primary-600">
                    ₹{result.tipAmount.toFixed(2)}
                  </div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <div className="text-sm text-gray-600 mb-1">Total Amount</div>
                  <div className="text-3xl font-bold text-primary-600">
                    ₹{result.totalAmount.toFixed(2)}
                  </div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <div className="text-sm text-gray-600 mb-1">Per Person</div>
                  <div className="text-3xl font-bold text-primary-600">
                    ₹{result.perPersonAmount.toFixed(2)}
                  </div>
                </div>
              </div>
              
              <p className="mt-4 text-sm text-gray-600">
                {parseFloat(tipPercentage) > 0 && parseFloat(billAmount) > 0 &&
                  `${tipPercentage}% tip on ₹${parseFloat(billAmount).toFixed(2)} is ₹${result.tipAmount.toFixed(2)}, for a total of ₹${result.totalAmount.toFixed(2)}.
                  ${splitBetween > 1 ? ` Split between ${splitBetween} people, each person pays ₹${result.perPersonAmount.toFixed(2)}.` : ''}`
                }
              </p>
            </div>
          )}
        </CardContent>
      </Card>
      
      <div className="prose max-w-none">
        <h2>Understanding Tipping</h2>
        <p>
          Tipping is a practice of giving a gratuity to service workers as appreciation for their service. It's customary in many countries, especially in restaurants, hotels, taxis, and other service industries.
        </p>
        
        <h2>Tipping Guidelines</h2>
        <p>
          While tipping amounts vary by region and service type, here are some common guidelines:
        </p>
        <ul>
          <li><strong>Restaurants:</strong> 15-20% of the pre-tax bill is standard in the US</li>
          <li><strong>Food Delivery:</strong> 10-15% of the order total</li>
          <li><strong>Taxi/Rideshare:</strong> 10-15% of the fare</li>
          <li><strong>Hotel Housekeeping:</strong> ₹100-250 per night</li>
          <li><strong>Barber/Hairstylist:</strong> 15-20% of the service cost</li>
        </ul>
        
        <h2>How to Use This Tip Calculator</h2>
        <ol>
          <li>Enter the total bill amount</li>
          <li>Select or input the tip percentage (15% is a common starting point)</li>
          <li>If dining with others, adjust the number of people splitting the bill</li>
          <li>View the calculated tip amount, total bill with tip, and per-person amount</li>
        </ol>
        
        <p>
          The calculator updates in real-time as you adjust any value, making it easy to try different scenarios or adjust your tip based on service quality.
        </p>
      </div>
    </div>
  );
};

export default TipCalculator;
