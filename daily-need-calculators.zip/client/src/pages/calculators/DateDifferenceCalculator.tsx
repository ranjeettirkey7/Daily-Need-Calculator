import { useState, useEffect } from "react";
import { calculateDateDifference } from "@/utils/calculatorUtils";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent } from "@/components/ui/card";

const DateDifferenceCalculator = () => {
  // Set default dates
  const today = new Date();
  const oneWeekAgo = new Date();
  oneWeekAgo.setDate(today.getDate() - 7);
  
  const [startDate, setStartDate] = useState<string>(oneWeekAgo.toISOString().split("T")[0]);
  const [endDate, setEndDate] = useState<string>(today.toISOString().split("T")[0]);
  const [includeBothDates, setIncludeBothDates] = useState<boolean>(false);
  const [result, setResult] = useState<{
    days: number;
    weeks: number;
    months: number;
  } | null>(null);

  // Calculate date difference
  const handleCalculateDifference = () => {
    if (!startDate || !endDate) return;

    const startDateObj = new Date(startDate);
    const endDateObj = new Date(endDate);
    
    const result = calculateDateDifference(startDateObj, endDateObj, includeBothDates);
    setResult(result);
  };

  // Recalculate when inputs change
  useEffect(() => {
    handleCalculateDifference();
  }, [startDate, endDate, includeBothDates]);

  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">Date Difference Calculator</h1>
      <p className="text-lg text-gray-600 mb-8">
        Find the exact number of days, weeks, and months between any two dates.
      </p>
      
      <Card className="mb-8">
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <Label htmlFor="startDate" className="block text-sm font-medium text-gray-700 mb-1">
                Start Date
              </Label>
              <Input
                type="date"
                id="startDate"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full"
                required
              />
            </div>
            <div>
              <Label htmlFor="endDate" className="block text-sm font-medium text-gray-700 mb-1">
                End Date
              </Label>
              <Input
                type="date"
                id="endDate"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full"
                required
              />
            </div>
          </div>
          
          <div className="flex items-center mb-6">
            <Checkbox
              id="includeBothDates"
              checked={includeBothDates}
              onCheckedChange={(checked) => setIncludeBothDates(checked as boolean)}
            />
            <Label htmlFor="includeBothDates" className="ml-2 block text-sm text-gray-700">
              Include both start and end dates in calculation
            </Label>
          </div>
          
          {result && (
            <div className="mt-6 border-t border-gray-200 pt-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Difference Between Dates:</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <div className="text-4xl font-bold text-primary-600">{result.days}</div>
                  <div className="text-sm text-gray-600">Days</div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <div className="text-4xl font-bold text-primary-600">{result.weeks}</div>
                  <div className="text-sm text-gray-600">Weeks</div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <div className="text-4xl font-bold text-primary-600">{result.months}</div>
                  <div className="text-sm text-gray-600">Months</div>
                </div>
              </div>
              
              <p className="mt-4 text-sm text-gray-600">
                From {new Date(startDate).toLocaleDateString()} to {new Date(endDate).toLocaleDateString()}, 
                there are {result.days} days ({includeBothDates ? 'including' : 'excluding'} both start and end dates).
              </p>
            </div>
          )}
        </CardContent>
      </Card>
      
      <div className="prose max-w-none">
        <h2>Why Calculate Date Differences?</h2>
        <p>
          Knowing the exact number of days between two dates is useful for many situations:
        </p>
        <ul>
          <li>Planning project timelines and deadlines</li>
          <li>Calculating age or duration of service</li>
          <li>Determining days until important events</li>
          <li>Tracking time between significant milestones</li>
          <li>Planning trips or booking accommodations</li>
        </ul>
        
        <h2>Understanding the Calculation</h2>
        <p>
          The Date Difference Calculator computes the exact number of days between any two dates, accounting for leap years, varying month lengths, and other calendar nuances. You can choose whether to include or exclude the start and end dates in your calculation.
        </p>
        
        <h2>Common Use Cases</h2>
        <p>
          People use date difference calculations for many practical reasons:
        </p>
        <ul>
          <li>Counting work or business days between dates</li>
          <li>Determining bill due dates and payment periods</li>
          <li>Calculating remaining time in contracts or subscriptions</li>
          <li>Planning event countdowns</li>
          <li>Tracking pregnancy progress or child development milestones</li>
        </ul>
        
        <p>
          Our calculator provides results in multiple time units (days, weeks, and months) to give you the most useful representation of the time difference for your specific needs.
        </p>
      </div>
    </div>
  );
};

export default DateDifferenceCalculator;
