import { useState, useEffect } from "react";
import { calculateSleepCycles } from "@/utils/calculatorUtils";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const SleepCalculator = () => {
  const [calculationType, setCalculationType] = useState<string>("sleep");
  
  // Sleep mode - "I want to go to sleep at..."
  const [bedtime, setBedtime] = useState<string>("");
  const [wakeupTimes, setWakeupTimes] = useState<string[]>([]);
  
  // Wake mode - "I want to wake up at..."
  const [wakeupTime, setWakeupTime] = useState<string>("");
  const [bedtimes, setBedtimes] = useState<string[]>([]);

  // Set default wakeup time to 7:00 AM
  useEffect(() => {
    const defaultWakeTime = new Date();
    defaultWakeTime.setHours(7, 0, 0);
    setWakeupTime(defaultWakeTime.toTimeString().substring(0, 5));
  }, []);

  // Calculate sleep cycles based on bedtime
  const handleCalculateSleepCycles = () => {
    if (!bedtime) return;
    
    const { sleepCycles } = calculateSleepCycles(bedtime);
    setWakeupTimes(sleepCycles);
  };
  
  // Calculate bedtimes based on wake-up time
  const handleCalculateBedtimes = () => {
    if (!wakeupTime) return;
    
    const { recommendedTimes } = calculateSleepCycles("", wakeupTime);
    setBedtimes(recommendedTimes);
  };
  
  // Recalculate when inputs change
  useEffect(() => {
    handleCalculateSleepCycles();
  }, [bedtime]);
  
  useEffect(() => {
    handleCalculateBedtimes();
  }, [wakeupTime]);

  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">Sleep Cycle Calculator</h1>
      <p className="text-lg text-gray-600 mb-8">
        Calculate optimal times to sleep or wake up based on 90-minute sleep cycles for better rest.
      </p>
      
      <Tabs defaultValue="sleep" onValueChange={setCalculationType}>
        <TabsList className="mb-6">
          <TabsTrigger value="sleep">I want to go to sleep at...</TabsTrigger>
          <TabsTrigger value="wake">I want to wake up at...</TabsTrigger>
        </TabsList>
        
        <TabsContent value="sleep">
          <Card className="mb-8">
            <CardContent className="pt-6">
              <div className="mb-6">
                <Label htmlFor="bedtime" className="block text-sm font-medium text-gray-700 mb-1">
                  I plan to go to bed at:
                </Label>
                <Input
                  type="time"
                  id="bedtime"
                  value={bedtime}
                  onChange={(e) => setBedtime(e.target.value)}
                  className="w-full md:w-48"
                  required
                />
                <p className="text-sm text-gray-500 mt-2">
                  It takes the average person 15 minutes to fall asleep.
                </p>
              </div>
              
              {bedtime && wakeupTimes.length > 0 && (
                <div className="mt-6 border-t border-gray-200 pt-6">
                  <h3 className="text-lg font-medium text-gray-900 mb-4">You should wake up at one of these times:</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
                    {wakeupTimes.map((time, index) => (
                      <div key={index} className="bg-gray-50 p-4 rounded-lg text-center">
                        <div className="text-2xl font-bold text-primary-600">{time}</div>
                        <div className="text-sm text-gray-600">{4 + index} sleep cycles</div>
                        <div className="text-xs text-gray-500 mt-1">({(4 + index) * 1.5} hours)</div>
                      </div>
                    ))}
                  </div>
                  <p className="text-sm text-gray-600">
                    These times represent when your body will be at the end of a sleep cycle, making it easier to wake up refreshed.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="wake">
          <Card className="mb-8">
            <CardContent className="pt-6">
              <div className="mb-6">
                <Label htmlFor="wakeupTime" className="block text-sm font-medium text-gray-700 mb-1">
                  I want to wake up at:
                </Label>
                <Input
                  type="time"
                  id="wakeupTime"
                  value={wakeupTime}
                  onChange={(e) => setWakeupTime(e.target.value)}
                  className="w-full md:w-48"
                  required
                />
              </div>
              
              {wakeupTime && bedtimes.length > 0 && (
                <div className="mt-6 border-t border-gray-200 pt-6">
                  <h3 className="text-lg font-medium text-gray-900 mb-4">You should fall asleep at one of these times:</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
                    {bedtimes.map((time, index) => (
                      <div key={index} className="bg-gray-50 p-4 rounded-lg text-center">
                        <div className="text-2xl font-bold text-primary-600">{time}</div>
                        <div className="text-sm text-gray-600">{4 + index} sleep cycles</div>
                        <div className="text-xs text-gray-500 mt-1">({(4 + index) * 1.5} hours)</div>
                      </div>
                    ))}
                  </div>
                  <p className="text-sm text-gray-600">
                    These times factor in the 15 minutes it takes the average person to fall asleep. Go to bed 15 minutes before these times.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      <div className="prose max-w-none">
        <h2>Understanding Sleep Cycles</h2>
        <p>
          Sleep isn't uniform throughout the night. Instead, your body cycles through different sleep stages, each serving unique biological purposes. A complete sleep cycle typically lasts 90 minutes and includes:
        </p>
        <ul>
          <li><strong>Light Sleep:</strong> The transition stage where your body begins to relax</li>
          <li><strong>Deep Sleep:</strong> The physically restorative stage where bodily tissues repair</li>
          <li><strong>REM Sleep:</strong> The mentally restorative stage where dreams occur and memories consolidate</li>
        </ul>
        
        <h2>Why Sleep Cycles Matter</h2>
        <p>
          Waking up during the middle of a sleep cycle can leave you feeling groggy and tired, even if you've slept for many hours. Conversely, waking up at the end of a cycle—even with fewer total hours of sleep—can help you feel more refreshed and alert.
        </p>
        
        <h2>How to Use This Sleep Calculator</h2>
        <p>
          This calculator works in two directions:
        </p>
        <ol>
          <li><strong>If you have a fixed bedtime:</strong> Enter when you plan to go to sleep, and the calculator will show optimal times to wake up (after 4, 5, or 6 complete sleep cycles)</li>
          <li><strong>If you have a fixed wake time:</strong> Enter when you need to wake up, and the calculator will show ideal times to fall asleep to complete 4, 5, or 6 sleep cycles</li>
        </ol>
        
        <h2>Tips for Better Sleep</h2>
        <ul>
          <li>Maintain a consistent sleep schedule, even on weekends</li>
          <li>Create a relaxing pre-sleep routine to wind down</li>
          <li>Keep your bedroom cool, dark, and quiet</li>
          <li>Avoid screens, caffeine, and heavy meals before bedtime</li>
          <li>Exercise regularly, but not too close to bedtime</li>
        </ul>
        
        <p>
          Remember that while sleep cycles are important, the quality and quantity of your sleep also matter significantly. Most adults need 7-9 hours of quality sleep per night for optimal health.
        </p>
      </div>
    </div>
  );
};

export default SleepCalculator;
