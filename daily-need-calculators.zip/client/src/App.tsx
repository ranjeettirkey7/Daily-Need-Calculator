import { Switch, Route, useLocation } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Layout from "@/components/Layout";
import Home from "@/pages/Home";
import AgeCalculator from "@/pages/calculators/AgeCalculator";
import DateDifferenceCalculator from "@/pages/calculators/DateDifferenceCalculator";
import TipCalculator from "@/pages/calculators/TipCalculator";
import DiscountCalculator from "@/pages/calculators/DiscountCalculator";
import UnitConverter from "@/pages/calculators/UnitConverter";
import FuelCostCalculator from "@/pages/calculators/FuelCostCalculator";
import WorkHoursCalculator from "@/pages/calculators/WorkHoursCalculator";
import SleepCalculator from "@/pages/calculators/SleepCalculator";
import EMICalculator from "@/pages/calculators/EMICalculator";
import TaxCalculator from "@/pages/calculators/TaxCalculator";

function Router() {
  const [location] = useLocation();
  
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/age-calculator" component={AgeCalculator} />
        <Route path="/date-difference" component={DateDifferenceCalculator} />
        <Route path="/tip-calculator" component={TipCalculator} />
        <Route path="/discount-calculator" component={DiscountCalculator} />
        <Route path="/unit-converter" component={UnitConverter} />
        <Route path="/fuel-cost" component={FuelCostCalculator} />
        <Route path="/work-hours" component={WorkHoursCalculator} />
        <Route path="/sleep-calculator" component={SleepCalculator} />
        <Route path="/emi-calculator" component={EMICalculator} />
        <Route path="/tax-calculator" component={TaxCalculator} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
