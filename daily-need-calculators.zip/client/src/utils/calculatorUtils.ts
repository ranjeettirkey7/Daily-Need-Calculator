// Age Calculator
export const calculateAge = (
  birthDate: Date,
  calculationDate: Date = new Date()
): { years: number; months: number; days: number; totalDays: number; totalWeeks: number; totalHours: number } => {
  if (!birthDate || birthDate > calculationDate) {
    return { years: 0, months: 0, days: 0, totalDays: 0, totalWeeks: 0, totalHours: 0 };
  }

  // Calculate difference
  let years = calculationDate.getFullYear() - birthDate.getFullYear();
  let months = calculationDate.getMonth() - birthDate.getMonth();
  let days = calculationDate.getDate() - birthDate.getDate();

  // Adjust for negative days
  if (days < 0) {
    months--;
    // Get days in previous month
    const prevMonth = new Date(calculationDate.getFullYear(), calculationDate.getMonth(), 0);
    days += prevMonth.getDate();
  }

  // Adjust for negative months
  if (months < 0) {
    years--;
    months += 12;
  }

  // Calculate total days for additional units
  const diffTime = Math.abs(calculationDate.getTime() - birthDate.getTime());
  const totalDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  const totalWeeks = Math.floor(totalDays / 7);
  const totalHours = totalDays * 24;

  return { years, months, days, totalDays, totalWeeks, totalHours };
};

// Date Difference Calculator
export const calculateDateDifference = (
  startDate: Date,
  endDate: Date,
  includeBothDates: boolean = false
): { days: number; weeks: number; months: number } => {
  if (!startDate || !endDate) {
    return { days: 0, weeks: 0, months: 0 };
  }

  // Ensure endDate is later than startDate
  if (startDate > endDate) {
    [startDate, endDate] = [endDate, startDate];
  }

  // Calculate days difference
  let diffTime = Math.abs(endDate.getTime() - startDate.getTime());
  let days = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  // Adjust if including both dates
  if (includeBothDates) {
    days += 1;
  }

  // Calculate weeks and months
  const weeks = Math.floor(days / 7);
  const months = (endDate.getFullYear() - startDate.getFullYear()) * 12 + (endDate.getMonth() - startDate.getMonth());

  return { days, weeks, months };
};

// Tip Calculator
export const calculateTip = (
  billAmount: number,
  tipPercentage: number,
  splitBetween: number = 1
): { tipAmount: number; totalAmount: number; perPersonAmount: number } => {
  if (billAmount <= 0 || tipPercentage < 0 || splitBetween <= 0) {
    return { tipAmount: 0, totalAmount: 0, perPersonAmount: 0 };
  }

  const tipAmount = billAmount * (tipPercentage / 100);
  const totalAmount = billAmount + tipAmount;
  const perPersonAmount = totalAmount / splitBetween;

  return { tipAmount, totalAmount, perPersonAmount };
};

// Discount Calculator
export const calculateDiscount = (
  originalPrice: number,
  discountPercentage: number
): { savingsAmount: number; finalPrice: number; percentageSaved: number } => {
  if (originalPrice <= 0 || discountPercentage < 0 || discountPercentage > 100) {
    return { savingsAmount: 0, finalPrice: 0, percentageSaved: 0 };
  }

  const savingsAmount = originalPrice * (discountPercentage / 100);
  const finalPrice = originalPrice - savingsAmount;
  const percentageSaved = discountPercentage;

  return { savingsAmount, finalPrice, percentageSaved };
};

// Conversion Data for Unit Converter
export const conversionData = {
  length: {
    m: { m: 1, km: 0.001, cm: 100, mm: 1000, in: 39.3701, ft: 3.28084, yd: 1.09361, mi: 0.000621371 },
    km: { m: 1000, km: 1, cm: 100000, mm: 1000000, in: 39370.1, ft: 3280.84, yd: 1093.61, mi: 0.621371 },
    cm: { m: 0.01, km: 0.00001, cm: 1, mm: 10, in: 0.393701, ft: 0.0328084, yd: 0.0109361, mi: 0.00000621371 },
    mm: { m: 0.001, km: 0.000001, cm: 0.1, mm: 1, in: 0.0393701, ft: 0.00328084, yd: 0.00109361, mi: 6.21371e-7 },
    in: { m: 0.0254, km: 0.0000254, cm: 2.54, mm: 25.4, in: 1, ft: 0.0833333, yd: 0.0277778, mi: 0.0000157828 },
    ft: { m: 0.3048, km: 0.0003048, cm: 30.48, mm: 304.8, in: 12, ft: 1, yd: 0.333333, mi: 0.000189394 },
    yd: { m: 0.9144, km: 0.0009144, cm: 91.44, mm: 914.4, in: 36, ft: 3, yd: 1, mi: 0.000568182 },
    mi: { m: 1609.34, km: 1.60934, cm: 160934, mm: 1609340, in: 63360, ft: 5280, yd: 1760, mi: 1 }
  },
  weight: {
    kg: { kg: 1, g: 1000, mg: 1000000, lb: 2.20462, oz: 35.274 },
    g: { kg: 0.001, g: 1, mg: 1000, lb: 0.00220462, oz: 0.035274 },
    mg: { kg: 0.000001, g: 0.001, mg: 1, lb: 2.20462e-6, oz: 0.000035274 },
    lb: { kg: 0.453592, g: 453.592, mg: 453592, lb: 1, oz: 16 },
    oz: { kg: 0.0283495, g: 28.3495, mg: 28349.5, lb: 0.0625, oz: 1 }
  },
  volume: {
    l: { l: 1, ml: 1000, gal: 0.264172, qt: 1.05669, pt: 2.11338, c: 4.22675 },
    ml: { l: 0.001, ml: 1, gal: 0.000264172, qt: 0.00105669, pt: 0.00211338, c: 0.00422675 },
    gal: { l: 3.78541, ml: 3785.41, gal: 1, qt: 4, pt: 8, c: 16 },
    qt: { l: 0.946353, ml: 946.353, gal: 0.25, qt: 1, pt: 2, c: 4 },
    pt: { l: 0.473176, ml: 473.176, gal: 0.125, qt: 0.5, pt: 1, c: 2 },
    c: { l: 0.236588, ml: 236.588, gal: 0.0625, qt: 0.25, pt: 0.5, c: 1 }
  },
  temperature: {
    c: {
      c: (c: number) => c,
      f: (c: number) => c * 9/5 + 32,
      k: (c: number) => c + 273.15
    },
    f: {
      c: (f: number) => (f - 32) * 5/9,
      f: (f: number) => f,
      k: (f: number) => (f - 32) * 5/9 + 273.15
    },
    k: {
      c: (k: number) => k - 273.15,
      f: (k: number) => (k - 273.15) * 9/5 + 32,
      k: (k: number) => k
    }
  },
  area: {
    m2: { m2: 1, km2: 0.000001, cm2: 10000, mm2: 1000000, in2: 1550, ft2: 10.7639, yd2: 1.19599, acre: 0.000247105 },
    km2: { m2: 1000000, km2: 1, cm2: 10000000000, mm2: 1000000000000, in2: 1550000000, ft2: 10763910.4, yd2: 1195990.05, acre: 247.105 },
    cm2: { m2: 0.0001, km2: 1e-10, cm2: 1, mm2: 100, in2: 0.155, ft2: 0.00107639, yd2: 0.000119599, acre: 2.47105e-8 },
    mm2: { m2: 0.000001, km2: 1e-12, cm2: 0.01, mm2: 1, in2: 0.00155, ft2: 0.0000107639, yd2: 0.00000119599, acre: 2.47105e-10 },
    in2: { m2: 0.00064516, km2: 6.4516e-10, cm2: 6.4516, mm2: 645.16, in2: 1, ft2: 0.00694444, yd2: 0.000771605, acre: 1.5942e-7 },
    ft2: { m2: 0.092903, km2: 9.2903e-8, cm2: 929.03, mm2: 92903, in2: 144, ft2: 1, yd2: 0.111111, acre: 0.0000229568 },
    yd2: { m2: 0.836127, km2: 8.36127e-7, cm2: 8361.27, mm2: 836127, in2: 1296, ft2: 9, yd2: 1, acre: 0.000206612 },
    acre: { m2: 4046.86, km2: 0.00404686, cm2: 40468600, mm2: 4046860000, in2: 6272640, ft2: 43560, yd2: 4840, acre: 1 }
  },
  speed: {
    mps: { mps: 1, kph: 3.6, mph: 2.23694, knot: 1.94384, fps: 3.28084 },
    kph: { mps: 0.277778, kph: 1, mph: 0.621371, knot: 0.539957, fps: 0.911344 },
    mph: { mps: 0.44704, kph: 1.60934, mph: 1, knot: 0.868976, fps: 1.46667 },
    knot: { mps: 0.514444, kph: 1.852, mph: 1.15078, knot: 1, fps: 1.68781 },
    fps: { mps: 0.3048, kph: 1.09728, mph: 0.681818, knot: 0.592484, fps: 1 }
  }
};

// Unit labels for Unit Converter
export const unitLabels = {
  length: {
    m: "Meters (m)",
    km: "Kilometers (km)",
    cm: "Centimeters (cm)",
    mm: "Millimeters (mm)",
    in: "Inches (in)",
    ft: "Feet (ft)",
    yd: "Yards (yd)",
    mi: "Miles (mi)"
  },
  weight: {
    kg: "Kilograms (kg)",
    g: "Grams (g)",
    mg: "Milligrams (mg)",
    lb: "Pounds (lb)",
    oz: "Ounces (oz)"
  },
  volume: {
    l: "Liters (l)",
    ml: "Milliliters (ml)",
    gal: "Gallons (gal)",
    qt: "Quarts (qt)",
    pt: "Pints (pt)",
    c: "Cups (c)"
  },
  temperature: {
    c: "Celsius (°C)",
    f: "Fahrenheit (°F)",
    k: "Kelvin (K)"
  },
  area: {
    m2: "Square Meters (m²)",
    km2: "Square Kilometers (km²)",
    cm2: "Square Centimeters (cm²)",
    mm2: "Square Millimeters (mm²)",
    in2: "Square Inches (in²)",
    ft2: "Square Feet (ft²)",
    yd2: "Square Yards (yd²)",
    acre: "Acres"
  },
  speed: {
    mps: "Meters per Second (m/s)",
    kph: "Kilometers per Hour (km/h)",
    mph: "Miles per Hour (mph)",
    knot: "Knots",
    fps: "Feet per Second (ft/s)"
  }
};

// Fuel Cost Calculator
export const calculateFuelCost = (
  distance: number,
  fuelEfficiency: number,
  fuelPrice: number
): { fuelAmount: number; totalCost: number } => {
  if (distance <= 0 || fuelEfficiency <= 0 || fuelPrice <= 0) {
    return { fuelAmount: 0, totalCost: 0 };
  }

  const fuelAmount = distance / fuelEfficiency;
  const totalCost = fuelAmount * fuelPrice;

  return { fuelAmount, totalCost };
};

// EMI Calculator
export const calculateEMI = (
  loanAmount: number,
  interestRate: number,
  loanTenure: number
): { monthlyEMI: number; totalInterest: number; totalPayment: number } => {
  if (loanAmount <= 0 || interestRate <= 0 || loanTenure <= 0) {
    return { monthlyEMI: 0, totalInterest: 0, totalPayment: 0 };
  }

  const monthlyInterestRate = interestRate / 12 / 100;
  const totalMonths = loanTenure * 12;
  
  // EMI formula: P × r × (1 + r)^n / ((1 + r)^n - 1)
  const monthlyEMI = loanAmount * monthlyInterestRate * Math.pow(1 + monthlyInterestRate, totalMonths) 
                      / (Math.pow(1 + monthlyInterestRate, totalMonths) - 1);
  
  const totalPayment = monthlyEMI * totalMonths;
  const totalInterest = totalPayment - loanAmount;

  return { monthlyEMI, totalInterest, totalPayment };
};

// Tax Calculator (GST)
export const calculateTax = (
  amount: number,
  taxRate: number,
  includeTax: boolean = false
): { taxAmount: number; totalAmount: number } => {
  if (amount <= 0 || taxRate < 0) {
    return { taxAmount: 0, totalAmount: 0 };
  }

  let taxAmount: number;
  let totalAmount: number;

  if (includeTax) {
    // Tax is already included in the amount (extract tax)
    taxAmount = amount - (amount / (1 + taxRate / 100));
    totalAmount = amount;
  } else {
    // Add tax to the amount
    taxAmount = amount * (taxRate / 100);
    totalAmount = amount + taxAmount;
  }

  return { taxAmount, totalAmount };
};

// Work Hours Calculator
export interface WorkDay {
  id: string;
  date: string;
  timeIn: string;
  timeOut: string;
  hoursWorked: number;
}

export const calculateWorkHours = (timeIn: string, timeOut: string): number => {
  if (!timeIn || !timeOut) return 0;

  const [inHours, inMinutes] = timeIn.split(':').map(Number);
  const [outHours, outMinutes] = timeOut.split(':').map(Number);

  let totalHours = outHours - inHours;
  let totalMinutes = outMinutes - inMinutes;

  if (totalMinutes < 0) {
    totalHours--;
    totalMinutes += 60;
  }

  if (totalHours < 0) {
    totalHours += 24; // Assuming night shift that crosses midnight
  }

  return parseFloat((totalHours + totalMinutes / 60).toFixed(2));
};

// Sleep Calculator
export const calculateSleepCycles = (
  sleepTime: string | Date,
  wakeUpTime?: string | Date
): { sleepCycles: string[]; recommendedTimes: string[] } => {
  const CYCLE_DURATION = 90; // minutes
  const FALL_ASLEEP_TIME = 15; // minutes it typically takes to fall asleep
  
  // Function to format time
  const formatTime = (date: Date): string => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  // Calculate wake-up times based on sleep time
  if (sleepTime) {
    let bedTime: Date;
    
    if (typeof sleepTime === 'string') {
      // If sleepTime is provided as string HH:MM
      const [hours, minutes] = sleepTime.split(':').map(Number);
      bedTime = new Date();
      bedTime.setHours(hours, minutes, 0, 0);
    } else {
      bedTime = new Date(sleepTime);
    }

    // Add time to fall asleep
    const actualSleepTime = new Date(bedTime.getTime() + FALL_ASLEEP_TIME * 60000);
    
    // Calculate wake-up times for different sleep cycles (4-6 cycles recommended)
    const wakeUpTimes: string[] = [];
    
    for (let cycles = 4; cycles <= 6; cycles++) {
      const wakeTime = new Date(actualSleepTime.getTime() + cycles * CYCLE_DURATION * 60000);
      wakeUpTimes.push(formatTime(wakeTime));
    }
    
    return { sleepCycles: wakeUpTimes, recommendedTimes: [] };
  } 
  // Calculate bedtime based on wake-up time
  else if (wakeUpTime) {
    let wakeTime: Date;
    
    if (typeof wakeUpTime === 'string') {
      // If wakeUpTime is provided as string HH:MM
      const [hours, minutes] = wakeUpTime.split(':').map(Number);
      wakeTime = new Date();
      wakeTime.setHours(hours, minutes, 0, 0);
    } else {
      wakeTime = new Date(wakeUpTime);
    }
    
    // Calculate bed times for different sleep cycles (4-6 cycles recommended)
    const bedTimes: string[] = [];
    
    for (let cycles = 4; cycles <= 6; cycles++) {
      // Subtract time to fall asleep and sleep cycles
      const bedTime = new Date(wakeTime.getTime() - (cycles * CYCLE_DURATION + FALL_ASLEEP_TIME) * 60000);
      bedTimes.push(formatTime(bedTime));
    }
    
    return { sleepCycles: [], recommendedTimes: bedTimes.reverse() };
  }
  
  return { sleepCycles: [], recommendedTimes: [] };
};
