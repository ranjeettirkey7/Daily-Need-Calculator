export type CalculatorInfo = {
  id: string;
  name: string;
  description: string;
  path: string;
  iconName: string;
};

export const calculators: CalculatorInfo[] = [
  {
    id: "age-calculator",
    name: "Age Calculator",
    description: "Calculate exact age in years, months, and days from date of birth.",
    path: "/age-calculator",
    iconName: "calendar",
  },
  {
    id: "date-difference",
    name: "Date Difference Calculator",
    description: "Find the number of days between two dates with real-time update.",
    path: "/date-difference",
    iconName: "calendar-days",
  },
  {
    id: "tip-calculator",
    name: "Tip Calculator",
    description: "Calculate tip amount and total bill based on bill amount and tip percentage.",
    path: "/tip-calculator",
    iconName: "dollar-sign",
  },
  {
    id: "discount-calculator",
    name: "Discount Calculator",
    description: "Calculate the final price and savings amount after applying a discount percentage.",
    path: "/discount-calculator",
    iconName: "percent",
  },
  {
    id: "unit-converter",
    name: "Unit Converter",
    description: "Convert between different units of measurement in real-time.",
    path: "/unit-converter",
    iconName: "arrows-up-down",
  },
  {
    id: "fuel-cost",
    name: "Fuel Cost Calculator",
    description: "Calculate estimated travel cost based on fuel price, distance, and mileage.",
    path: "/fuel-cost",
    iconName: "zap",
  },
  {
    id: "work-hours",
    name: "Work Hours Calculator",
    description: "Track daily/weekly total hours worked with in-and-out times.",
    path: "/work-hours",
    iconName: "clock",
  },
  {
    id: "sleep-calculator",
    name: "Sleep Calculator",
    description: "Calculate optimal times to sleep or wake up based on sleep cycle theory.",
    path: "/sleep-calculator",
    iconName: "moon",
  },
  {
    id: "emi-calculator",
    name: "EMI Calculator",
    description: "Calculate monthly EMI, total interest, and total payable for loans.",
    path: "/emi-calculator",
    iconName: "calculator",
  },
  {
    id: "tax-calculator",
    name: "GST / Tax Calculator",
    description: "Calculate tax-inclusive or tax-exclusive prices with GST/tax percentage.",
    path: "/tax-calculator",
    iconName: "file-text",
  },
];
