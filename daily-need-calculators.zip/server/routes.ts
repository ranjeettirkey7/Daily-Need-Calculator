import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // API endpoints for calculator operations
  
  // Age Calculator API endpoint
  app.post("/api/age-calculator", (req, res) => {
    try {
      const { birthDate, calculationDate } = req.body;
      
      if (!birthDate) {
        return res.status(400).json({ error: "Birth date is required" });
      }
      
      const birthDateObj = new Date(birthDate);
      const calculationDateObj = calculationDate ? new Date(calculationDate) : new Date();
      
      // Calculate difference
      let years = calculationDateObj.getFullYear() - birthDateObj.getFullYear();
      let months = calculationDateObj.getMonth() - birthDateObj.getMonth();
      let days = calculationDateObj.getDate() - birthDateObj.getDate();
      
      // Adjust for negative days
      if (days < 0) {
        months--;
        // Get days in previous month
        const prevMonth = new Date(calculationDateObj.getFullYear(), calculationDateObj.getMonth(), 0);
        days += prevMonth.getDate();
      }
      
      // Adjust for negative months
      if (months < 0) {
        years--;
        months += 12;
      }
      
      // Calculate total days for additional units
      const diffTime = Math.abs(calculationDateObj.getTime() - birthDateObj.getTime());
      const totalDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      const totalWeeks = Math.floor(totalDays / 7);
      const totalHours = totalDays * 24;
      
      return res.json({
        years,
        months,
        days,
        totalDays,
        totalWeeks,
        totalHours
      });
    } catch (error) {
      return res.status(500).json({ error: "Failed to calculate age" });
    }
  });
  
  // Date Difference Calculator API endpoint
  app.post("/api/date-difference", (req, res) => {
    try {
      const { startDate, endDate, includeBothDates } = req.body;
      
      if (!startDate || !endDate) {
        return res.status(400).json({ error: "Both start and end dates are required" });
      }
      
      const startDateObj = new Date(startDate);
      const endDateObj = new Date(endDate);
      
      // Calculate days difference
      let diffTime = Math.abs(endDateObj.getTime() - startDateObj.getTime());
      let days = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
      // Adjust if including both dates
      if (includeBothDates) {
        days += 1;
      }
      
      // Calculate weeks and months
      const weeks = Math.floor(days / 7);
      const months = (endDateObj.getFullYear() - startDateObj.getFullYear()) * 12 + 
                    (endDateObj.getMonth() - startDateObj.getMonth());
      
      return res.json({
        days,
        weeks,
        months
      });
    } catch (error) {
      return res.status(500).json({ error: "Failed to calculate date difference" });
    }
  });
  
  // Tip Calculator API endpoint
  app.post("/api/tip-calculator", (req, res) => {
    try {
      const { billAmount, tipPercentage, splitBetween } = req.body;
      
      if (billAmount === undefined || tipPercentage === undefined) {
        return res.status(400).json({ error: "Bill amount and tip percentage are required" });
      }
      
      const bill = parseFloat(billAmount);
      const tip = parseFloat(tipPercentage);
      const split = parseInt(splitBetween) || 1;
      
      if (bill <= 0 || tip < 0 || split <= 0) {
        return res.status(400).json({ error: "Invalid input values" });
      }
      
      const tipAmount = bill * (tip / 100);
      const totalAmount = bill + tipAmount;
      const perPersonAmount = totalAmount / split;
      
      return res.json({
        tipAmount,
        totalAmount,
        perPersonAmount
      });
    } catch (error) {
      return res.status(500).json({ error: "Failed to calculate tip" });
    }
  });
  
  // Discount Calculator API endpoint
  app.post("/api/discount-calculator", (req, res) => {
    try {
      const { originalPrice, discountPercentage } = req.body;
      
      if (originalPrice === undefined || discountPercentage === undefined) {
        return res.status(400).json({ error: "Original price and discount percentage are required" });
      }
      
      const price = parseFloat(originalPrice);
      const discount = parseFloat(discountPercentage);
      
      if (price <= 0 || discount < 0 || discount > 100) {
        return res.status(400).json({ error: "Invalid input values" });
      }
      
      const savingsAmount = price * (discount / 100);
      const finalPrice = price - savingsAmount;
      
      return res.json({
        savingsAmount,
        finalPrice,
        percentageSaved: discount
      });
    } catch (error) {
      return res.status(500).json({ error: "Failed to calculate discount" });
    }
  });
  
  // Unit Converter API endpoint
  app.post("/api/unit-converter", (req, res) => {
    try {
      const { category, fromUnit, toUnit, value } = req.body;
      
      if (!category || !fromUnit || !toUnit || value === undefined) {
        return res.status(400).json({ error: "Category, units, and value are required" });
      }
      
      // Conversion rates for different categories
      const conversionRates: Record<string, Record<string, Record<string, number | ((val: number) => number)>>> = {
        length: {
          m: { m: 1, km: 0.001, cm: 100, mm: 1000, in: 39.3701, ft: 3.28084, yd: 1.09361, mi: 0.000621371 },
          km: { m: 1000, km: 1, cm: 100000, mm: 1000000, in: 39370.1, ft: 3280.84, yd: 1093.61, mi: 0.621371 },
          cm: { m: 0.01, km: 0.00001, cm: 1, mm: 10, in: 0.393701, ft: 0.0328084, yd: 0.0109361, mi: 0.00000621371 },
          mm: { m: 0.001, km: 0.000001, cm: 0.1, mm: 1, in: 0.0393701, ft: 0.00328084, yd: 0.00109361, mi: 6.21371e-7 },
          in: { m: 0.0254, km: 0.0000254, cm: 2.54, mm: 25.4, in: 1, ft: 0.0833333, yd: 0.0277778, mi: 0.0000157828 },
          ft: { m: 0.3048, km: 0.0003048, cm: 30.48, mm: 304.8, in: 12, ft: 1, yd: 0.333333, mi: 0.000189394 },
          yd: { m: 0.9144, km: 0.0009144, cm: 91.44, mm: 914.4, in: 36, ft: 3, yd: 1, mi: 0.000568182 },
          mi: { m: 1609.34, km: 1.60934, cm: 160934, mm: 1609340, in: 63360, ft: 5280, yd: 1760, mi: 1 }
        },
        // Add other conversion categories as needed
      };
      
      // Check if category exists
      if (!conversionRates[category]) {
        return res.status(400).json({ error: "Invalid conversion category" });
      }
      
      // Check if units exist in the category
      if (!conversionRates[category][fromUnit] || !conversionRates[category][fromUnit][toUnit]) {
        return res.status(400).json({ error: "Invalid conversion units" });
      }
      
      let result: number;
      const conversionRate = conversionRates[category][fromUnit][toUnit];
      
      // Handle temperature conversions which use functions
      if (typeof conversionRate === 'function') {
        result = conversionRate(parseFloat(value));
      } else {
        result = parseFloat(value) * conversionRate;
      }
      
      return res.json({
        result,
        fromUnit,
        toUnit,
        originalValue: parseFloat(value)
      });
    } catch (error) {
      return res.status(500).json({ error: "Failed to convert units" });
    }
  });
  
  // Fuel Cost Calculator API endpoint
  app.post("/api/fuel-cost", (req, res) => {
    try {
      const { distance, fuelEfficiency, fuelPrice } = req.body;
      
      if (distance === undefined || fuelEfficiency === undefined || fuelPrice === undefined) {
        return res.status(400).json({ error: "Distance, fuel efficiency, and fuel price are required" });
      }
      
      const distanceVal = parseFloat(distance);
      const efficiencyVal = parseFloat(fuelEfficiency);
      const priceVal = parseFloat(fuelPrice);
      
      if (distanceVal <= 0 || efficiencyVal <= 0 || priceVal <= 0) {
        return res.status(400).json({ error: "Invalid input values" });
      }
      
      const fuelAmount = distanceVal / efficiencyVal;
      const totalCost = fuelAmount * priceVal;
      
      return res.json({
        fuelAmount,
        totalCost
      });
    } catch (error) {
      return res.status(500).json({ error: "Failed to calculate fuel cost" });
    }
  });
  
  // Work Hours Calculator API endpoint
  app.post("/api/work-hours", (req, res) => {
    try {
      const { timeIn, timeOut, breakDuration } = req.body;
      
      if (!timeIn || !timeOut) {
        return res.status(400).json({ error: "Time in and time out are required" });
      }
      
      // Parse time strings to calculate hours
      const [inHours, inMinutes] = timeIn.split(':').map(Number);
      const [outHours, outMinutes] = timeOut.split(':').map(Number);
      
      let totalHours = outHours - inHours;
      let totalMinutes = outMinutes - inMinutes;
      
      if (totalMinutes < 0) {
        totalHours--;
        totalMinutes += 60;
      }
      
      if (totalHours < 0) {
        totalHours += 24; // Assuming night shift that crosses midnight
      }
      
      const hoursWorked = totalHours + totalMinutes / 60;
      const breakHours = parseFloat(breakDuration) || 0;
      
      return res.json({
        hoursWorked: Math.max(0, hoursWorked - breakHours)
      });
    } catch (error) {
      return res.status(500).json({ error: "Failed to calculate work hours" });
    }
  });
  
  // Sleep Calculator API endpoint
  app.post("/api/sleep-calculator", (req, res) => {
    try {
      const { sleepTime, wakeUpTime } = req.body;
      const CYCLE_DURATION = 90; // minutes
      const FALL_ASLEEP_TIME = 15; // minutes
      
      // Format time function
      const formatTime = (date: Date): string => {
        return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      };
      
      if (sleepTime) {
        // Calculate wake-up times based on sleep time
        const [hours, minutes] = sleepTime.split(':').map(Number);
        const bedTime = new Date();
        bedTime.setHours(hours, minutes, 0, 0);
        
        // Add time to fall asleep
        const actualSleepTime = new Date(bedTime.getTime() + FALL_ASLEEP_TIME * 60000);
        
        // Calculate wake-up times for 4-6 sleep cycles
        const wakeUpTimes = [];
        
        for (let cycles = 4; cycles <= 6; cycles++) {
          const wakeTime = new Date(actualSleepTime.getTime() + cycles * CYCLE_DURATION * 60000);
          wakeUpTimes.push(formatTime(wakeTime));
        }
        
        return res.json({ sleepCycles: wakeUpTimes, recommendedTimes: [] });
      } else if (wakeUpTime) {
        // Calculate bedtimes based on wake-up time
        const [hours, minutes] = wakeUpTime.split(':').map(Number);
        const wakeTime = new Date();
        wakeTime.setHours(hours, minutes, 0, 0);
        
        // Calculate bed times for different sleep cycles
        const bedTimes = [];
        
        for (let cycles = 4; cycles <= 6; cycles++) {
          // Subtract time to fall asleep and sleep cycles
          const bedTime = new Date(wakeTime.getTime() - (cycles * CYCLE_DURATION + FALL_ASLEEP_TIME) * 60000);
          bedTimes.push(formatTime(bedTime));
        }
        
        return res.json({ sleepCycles: [], recommendedTimes: bedTimes.reverse() });
      } else {
        return res.status(400).json({ error: "Either sleep time or wake-up time is required" });
      }
    } catch (error) {
      return res.status(500).json({ error: "Failed to calculate sleep cycles" });
    }
  });
  
  // EMI Calculator API endpoint
  app.post("/api/emi-calculator", (req, res) => {
    try {
      const { loanAmount, interestRate, loanTenure } = req.body;
      
      if (loanAmount === undefined || interestRate === undefined || loanTenure === undefined) {
        return res.status(400).json({ error: "Loan amount, interest rate, and loan tenure are required" });
      }
      
      const principal = parseFloat(loanAmount);
      const rate = parseFloat(interestRate);
      const years = parseFloat(loanTenure);
      
      if (principal <= 0 || rate <= 0 || years <= 0) {
        return res.status(400).json({ error: "Invalid input values" });
      }
      
      const monthlyInterestRate = rate / 12 / 100;
      const totalMonths = years * 12;
      
      // EMI formula: P × r × (1 + r)^n / ((1 + r)^n - 1)
      const monthlyEMI = principal * monthlyInterestRate * Math.pow(1 + monthlyInterestRate, totalMonths) 
                        / (Math.pow(1 + monthlyInterestRate, totalMonths) - 1);
      
      const totalPayment = monthlyEMI * totalMonths;
      const totalInterest = totalPayment - principal;
      
      return res.json({
        monthlyEMI,
        totalInterest,
        totalPayment
      });
    } catch (error) {
      return res.status(500).json({ error: "Failed to calculate EMI" });
    }
  });
  
  // Tax/GST Calculator API endpoint
  app.post("/api/tax-calculator", (req, res) => {
    try {
      const { amount, taxRate, includeTax } = req.body;
      
      if (amount === undefined || taxRate === undefined) {
        return res.status(400).json({ error: "Amount and tax rate are required" });
      }
      
      const amountVal = parseFloat(amount);
      const rateVal = parseFloat(taxRate);
      
      if (amountVal < 0 || rateVal < 0) {
        return res.status(400).json({ error: "Invalid input values" });
      }
      
      let taxAmount: number;
      let totalAmount: number;
      
      if (includeTax) {
        // Tax is already included in the amount (extract tax)
        taxAmount = amountVal - (amountVal / (1 + rateVal / 100));
        totalAmount = amountVal;
      } else {
        // Add tax to the amount
        taxAmount = amountVal * (rateVal / 100);
        totalAmount = amountVal + taxAmount;
      }
      
      return res.json({
        taxAmount,
        totalAmount
      });
    } catch (error) {
      return res.status(500).json({ error: "Failed to calculate tax" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
